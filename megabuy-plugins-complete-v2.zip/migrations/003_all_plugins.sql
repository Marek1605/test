-- Migration: Complete tables for ALL WordPress plugins
-- Run this after init.sql

-- =====================================================
-- VENDOR SHOPS (from AMARKETPLACEVENDORPORTAL)
-- =====================================================
CREATE TABLE IF NOT EXISTS vendor_shops (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    shop_name VARCHAR(255) NOT NULL,
    shop_slug VARCHAR(255) UNIQUE NOT NULL,
    shop_url VARCHAR(500),
    shop_logo VARCHAR(500),
    shop_description TEXT,
    shop_status VARCHAR(50) DEFAULT 'pending', -- pending, active, suspended, rejected
    optimization_score INT DEFAULT 0,
    total_products INT DEFAULT 0,
    total_clicks INT DEFAULT 0,
    total_conversions INT DEFAULT 0,
    credit_balance DECIMAL(10,2) DEFAULT 0.00,
    display_mode VARCHAR(20) DEFAULT 'free', -- free, paid, premium
    ppc_enabled BOOLEAN DEFAULT false,
    auto_recharge BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_vendor_shops_vendor ON vendor_shops(vendor_id);
CREATE INDEX IF NOT EXISTS idx_vendor_shops_status ON vendor_shops(shop_status);
CREATE INDEX IF NOT EXISTS idx_vendor_shops_slug ON vendor_shops(shop_slug);

-- =====================================================
-- VENDOR SETTINGS (from ANASTAVENIEVENDORA)
-- =====================================================
CREATE TABLE IF NOT EXISTS vendor_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    setting_key VARCHAR(255) NOT NULL,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(vendor_id, setting_key)
);

CREATE INDEX IF NOT EXISTS idx_vendor_settings_vendor ON vendor_settings(vendor_id);

-- =====================================================
-- PRODUCT APPROVALS (from APRODUKTY-VENDOR PLUGIN)
-- =====================================================
CREATE TABLE IF NOT EXISTS product_approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    vendor_id UUID REFERENCES vendors(id) ON DELETE CASCADE,
    action VARCHAR(50) NOT NULL, -- created, updated, price_change, category_change
    old_value TEXT,
    new_value TEXT,
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected
    admin_id UUID,
    admin_note TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    resolved_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_product_approvals_status ON product_approvals(status);
CREATE INDEX IF NOT EXISTS idx_product_approvals_vendor ON product_approvals(vendor_id);

-- =====================================================
-- ANALYTICS SUBSCRIPTIONS (from ANALITIKAPREVENDOROV)
-- =====================================================
CREATE TABLE IF NOT EXISTS analytics_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    plan VARCHAR(50) NOT NULL, -- basic, pro, enterprise
    status VARCHAR(20) DEFAULT 'active', -- active, cancelled, expired
    price DECIMAL(10,2) NOT NULL,
    billing_cycle VARCHAR(20) DEFAULT 'monthly', -- monthly, yearly
    start_date TIMESTAMP NOT NULL,
    end_date TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_analytics_subscriptions_vendor ON analytics_subscriptions(vendor_id);
CREATE INDEX IF NOT EXISTS idx_analytics_subscriptions_status ON analytics_subscriptions(status);

-- =====================================================
-- REVIEWS (from ARECENZIE)
-- =====================================================
CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    vendor_id UUID REFERENCES vendors(id) ON DELETE CASCADE,
    user_id UUID,
    user_name VARCHAR(255) NOT NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(500),
    content TEXT,
    pros TEXT[],
    cons TEXT[],
    is_verified BOOLEAN DEFAULT false,
    is_approved BOOLEAN DEFAULT false,
    helpful_count INTEGER DEFAULT 0,
    reply_content TEXT,
    reply_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_vendor ON reviews(vendor_id);
CREATE INDEX IF NOT EXISTS idx_reviews_approved ON reviews(is_approved);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);

-- =====================================================
-- TRANSACTIONS (from mk-cpc-system)
-- =====================================================
CREATE TABLE IF NOT EXISTS transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id UUID REFERENCES vendors(id) ON DELETE CASCADE,
    type VARCHAR(20) NOT NULL, -- CREDIT, DEBIT, BONUS, REFUND
    amount DECIMAL(10,2) NOT NULL,
    balance DECIMAL(10,2) NOT NULL,
    description TEXT,
    reference_id VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_vendor ON transactions(vendor_id);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);
CREATE INDEX IF NOT EXISTS idx_transactions_created ON transactions(created_at);

-- =====================================================
-- BRANDS (from AIMPORTVENDOROVPROFIPLUGIN)
-- =====================================================
CREATE TABLE IF NOT EXISTS brands (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    logo_url VARCHAR(500),
    website_url VARCHAR(500),
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_brands_slug ON brands(slug);

-- =====================================================
-- PRODUCT ATTRIBUTES
-- =====================================================
CREATE TABLE IF NOT EXISTS attributes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    type VARCHAR(50) DEFAULT 'text', -- text, number, select, boolean
    unit VARCHAR(50),
    is_filterable BOOLEAN DEFAULT false,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS product_attribute_values (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    attribute_id UUID REFERENCES attributes(id) ON DELETE CASCADE,
    value TEXT NOT NULL,
    UNIQUE(product_id, attribute_id)
);

CREATE INDEX IF NOT EXISTS idx_pav_product ON product_attribute_values(product_id);
CREATE INDEX IF NOT EXISTS idx_pav_attribute ON product_attribute_values(attribute_id);

-- =====================================================
-- ALTER EXISTING TABLES
-- =====================================================

-- Products table additions
ALTER TABLE products ADD COLUMN IF NOT EXISTS brand_id UUID REFERENCES brands(id);
ALTER TABLE products ADD COLUMN IF NOT EXISTS rating DECIMAL(2,1) DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS review_count INTEGER DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS short_description TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS meta_description VARCHAR(255);
ALTER TABLE products ADD COLUMN IF NOT EXISTS is_master BOOLEAN DEFAULT true;

-- Offers table additions
ALTER TABLE offers ADD COLUMN IF NOT EXISTS click_count INTEGER DEFAULT 0;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS cpc_rate DECIMAL(10,4);
ALTER TABLE offers ADD COLUMN IF NOT EXISTS checksum VARCHAR(64);
ALTER TABLE offers ADD COLUMN IF NOT EXISTS last_sync_at TIMESTAMP;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS original_price DECIMAL(10,2);
ALTER TABLE offers ADD COLUMN IF NOT EXISTS stock_count INTEGER DEFAULT 0;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS delivery_days INTEGER;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS delivery_price DECIMAL(10,2) DEFAULT 0;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS ean VARCHAR(50);
ALTER TABLE offers ADD COLUMN IF NOT EXISTS external_id VARCHAR(255);

-- Vendors table additions
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS credit_balance DECIMAL(10,2) DEFAULT 0;
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS display_mode VARCHAR(20) DEFAULT 'FREE';
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS cpc_rate DECIMAL(10,4) DEFAULT 0.05;
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS is_megabuy BOOLEAN DEFAULT false;
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS rating DECIMAL(2,1) DEFAULT 0;
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS review_count INTEGER DEFAULT 0;

-- Clicks table additions
ALTER TABLE clicks ADD COLUMN IF NOT EXISTS cost DECIMAL(10,4) DEFAULT 0;
ALTER TABLE clicks ADD COLUMN IF NOT EXISTS is_charged BOOLEAN DEFAULT false;

-- Feed history additions
ALTER TABLE feed_history ADD COLUMN IF NOT EXISTS progress INTEGER DEFAULT 0;
ALTER TABLE feed_history ADD COLUMN IF NOT EXISTS error_details TEXT[];

-- =====================================================
-- VIEWS FOR STATISTICS
-- =====================================================

CREATE OR REPLACE VIEW vendor_stats_daily AS
SELECT 
    vendor_id,
    DATE(created_at) as date,
    COUNT(*) as clicks,
    COUNT(*) FILTER (WHERE is_charged = true) as charged_clicks,
    COALESCE(SUM(cost), 0) as cost
FROM clicks
GROUP BY vendor_id, DATE(created_at);

CREATE OR REPLACE VIEW product_stats AS
SELECT 
    p.id,
    p.title,
    p.slug,
    COUNT(DISTINCT o.id) as offer_count,
    MIN(o.price) as price_min,
    MAX(o.price) as price_max,
    COALESCE(SUM(o.click_count), 0) as total_clicks,
    p.rating,
    p.review_count
FROM products p
LEFT JOIN offers o ON p.id = o.product_id AND o.is_active = true
GROUP BY p.id;

CREATE OR REPLACE VIEW vendor_overview AS
SELECT 
    v.id,
    v.name,
    v.slug,
    v.credit_balance,
    v.display_mode,
    COUNT(DISTINCT o.id) as total_offers,
    COUNT(DISTINCT o.id) FILTER (WHERE o.is_active = true) as active_offers,
    COALESCE(SUM(o.click_count), 0) as total_clicks
FROM vendors v
LEFT JOIN offers o ON v.id = o.vendor_id
GROUP BY v.id;

-- =====================================================
-- TRIGGER FUNCTIONS
-- =====================================================

-- Update product stats trigger
CREATE OR REPLACE FUNCTION update_product_stats()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE products 
    SET 
        price_min = (SELECT MIN(price) FROM offers WHERE product_id = COALESCE(NEW.product_id, OLD.product_id) AND is_active = true),
        price_max = (SELECT MAX(price) FROM offers WHERE product_id = COALESCE(NEW.product_id, OLD.product_id) AND is_active = true),
        offer_count = (SELECT COUNT(*) FROM offers WHERE product_id = COALESCE(NEW.product_id, OLD.product_id) AND is_active = true),
        updated_at = NOW()
    WHERE id = COALESCE(NEW.product_id, OLD.product_id);
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_product_stats ON offers;
CREATE TRIGGER trigger_update_product_stats
    AFTER INSERT OR UPDATE OR DELETE ON offers
    FOR EACH ROW
    EXECUTE FUNCTION update_product_stats();

-- Update review stats trigger
CREATE OR REPLACE FUNCTION update_review_stats()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.product_id IS NOT NULL THEN
        UPDATE products 
        SET 
            rating = (SELECT COALESCE(AVG(rating), 0) FROM reviews WHERE product_id = NEW.product_id AND is_approved = true),
            review_count = (SELECT COUNT(*) FROM reviews WHERE product_id = NEW.product_id AND is_approved = true),
            updated_at = NOW()
        WHERE id = NEW.product_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_review_stats ON reviews;
CREATE TRIGGER trigger_update_review_stats
    AFTER INSERT OR UPDATE ON reviews
    FOR EACH ROW
    EXECUTE FUNCTION update_review_stats();

-- Update vendor shop stats trigger
CREATE OR REPLACE FUNCTION update_vendor_shop_stats()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE vendor_shops vs SET
        total_products = (SELECT COUNT(*) FROM offers WHERE vendor_id = vs.vendor_id AND is_active = true),
        total_clicks = (SELECT COUNT(*) FROM clicks WHERE vendor_id = vs.vendor_id),
        updated_at = NOW()
    WHERE vendor_id = COALESCE(NEW.vendor_id, OLD.vendor_id);
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_shop_stats_offers ON offers;
CREATE TRIGGER trigger_update_shop_stats_offers
    AFTER INSERT OR UPDATE OR DELETE ON offers
    FOR EACH ROW
    EXECUTE FUNCTION update_vendor_shop_stats();

DROP TRIGGER IF EXISTS trigger_update_shop_stats_clicks ON clicks;
CREATE TRIGGER trigger_update_shop_stats_clicks
    AFTER INSERT ON clicks
    FOR EACH ROW
    EXECUTE FUNCTION update_vendor_shop_stats();
