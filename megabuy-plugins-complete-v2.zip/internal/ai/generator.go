package ai

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog/log"
)

// AIGenerator handles AI-powered content generation
type AIGenerator struct {
	pool       *pgxpool.Pool
	ctx        context.Context
	apiKey     string
	apiURL     string
}

func NewAIGenerator(pool *pgxpool.Pool, apiKey string) *AIGenerator {
	return &AIGenerator{
		pool:   pool,
		ctx:    context.Background(),
		apiKey: apiKey,
		apiURL: "https://api.anthropic.com/v1/messages",
	}
}

// Description styles
var DescriptionStyles = map[string]string{
	"professional": "Profesionálny, informatívny štýl vhodný pre B2B",
	"casual":       "Priateľský, konverzačný štýl pre bežných spotrebiteľov",
	"luxury":       "Luxusný, prémiový štýl pre high-end produkty",
	"technical":    "Technický štýl s dôrazom na parametre",
	"storytelling": "Príbehový štýl s emočným nábojom",
	"minimal":      "Minimalistický, stručný štýl",
	"seo":          "SEO optimalizovaný štýl s kľúčovými slovami",
}

// ProductContext for AI prompts
type ProductContext struct {
	Title       string            `json:"title"`
	Category    string            `json:"category"`
	Brand       string            `json:"brand"`
	Price       float64           `json:"price"`
	Description string            `json:"description"`
	EAN         string            `json:"ean"`
	Attributes  map[string]string `json:"attributes"`
}

// GeneratedDescription result
type GeneratedDescription struct {
	ShortDescription string   `json:"short_description"`
	FullDescription  string   `json:"full_description"`
	MetaDescription  string   `json:"meta_description"`
	Keywords         []string `json:"keywords"`
}

// GenerateDescription creates product description using AI
func (ai *AIGenerator) GenerateDescription(productID uuid.UUID, style string, length string) (*GeneratedDescription, error) {
	ctx := ai.getProductContext(productID)
	if ctx == nil {
		return nil, fmt.Errorf("product not found")
	}

	styleDesc := DescriptionStyles[style]
	if styleDesc == "" {
		styleDesc = DescriptionStyles["professional"]
	}

	lengthGuide := map[string]string{
		"short":  "100-150 slov",
		"medium": "200-300 slov",
		"long":   "400-500 slov",
	}
	lengthText := lengthGuide[length]
	if lengthText == "" {
		lengthText = lengthGuide["medium"]
	}

	systemPrompt := fmt.Sprintf(`Si expert copywriter pre e-commerce. Tvojou úlohou je napísať presvedčivý popis produktu.

ŠTÝL: %s
DĹŽKA: %s

PRAVIDLÁ:
- Odpovedaj vždy po SLOVENSKY
- Používaj HTML formátovanie (<p>, <ul>, <li>, <strong>, <em>)
- Začni pútavým úvodom
- Zvýrazni hlavné výhody a vlastnosti
- Ukonči výzvou k akcii
- Nepoužívaj prehnané superlativy
- Buď presný a konkrétny

FORMÁT ODPOVEDE (JSON):
{
  "short_description": "Krátky popis pre náhľad (max 150 znakov)",
  "full_description": "Plný HTML popis produktu",
  "meta_description": "SEO meta popis (max 160 znakov)",
  "keywords": ["kľúčové", "slová", "pre", "SEO"]
}

Vráť IBA JSON, žiadny iný text.`, styleDesc, lengthText)

	userMessage := fmt.Sprintf(`Napíš popis pre tento produkt:

Názov: %s
Kategória: %s
Značka: %s
Cena: %.2f €
Existujúci popis: %s
EAN: %s`, ctx.Title, ctx.Category, ctx.Brand, ctx.Price, ctx.Description, ctx.EAN)

	response, err := ai.sendMessage(systemPrompt, userMessage)
	if err != nil {
		return nil, err
	}

	return ai.parseDescriptionResponse(response)
}

// GeneratedFAQ result
type GeneratedFAQ struct {
	Questions []FAQItem `json:"questions"`
}

type FAQItem struct {
	Question string `json:"question"`
	Answer   string `json:"answer"`
}

// GenerateFAQ creates FAQ for product
func (ai *AIGenerator) GenerateFAQ(productID uuid.UUID, count int) (*GeneratedFAQ, error) {
	ctx := ai.getProductContext(productID)
	if ctx == nil {
		return nil, fmt.Errorf("product not found")
	}

	if count < 3 {
		count = 5
	}
	if count > 10 {
		count = 10
	}

	systemPrompt := fmt.Sprintf(`Si expert na produkty a zákaznícky servis. Vygeneruj %d najčastejších otázok a odpovedí pre produkt.

PRAVIDLÁ:
- Odpovedaj po SLOVENSKY
- Otázky musia byť relevantné a praktické
- Odpovede musia byť stručné ale informatívne (2-3 vety)
- Zahrň otázky o vlastnostiach, použití, údržbe, kompatibilite

FORMÁT ODPOVEDE (JSON):
{
  "questions": [
    {"question": "Otázka 1?", "answer": "Odpoveď 1."},
    {"question": "Otázka 2?", "answer": "Odpoveď 2."}
  ]
}

Vráť IBA JSON.`, count)

	userMessage := fmt.Sprintf(`Vygeneruj FAQ pre:

Produkt: %s
Kategória: %s
Značka: %s
Popis: %s`, ctx.Title, ctx.Category, ctx.Brand, ctx.Description)

	response, err := ai.sendMessage(systemPrompt, userMessage)
	if err != nil {
		return nil, err
	}

	return ai.parseFAQResponse(response)
}

// WhyBuyReasons result
type WhyBuyReasons struct {
	Reasons []WhyBuyReason `json:"reasons"`
}

type WhyBuyReason struct {
	Icon  string `json:"icon"`
	Title string `json:"title"`
	Text  string `json:"text"`
}

// GenerateWhyBuy creates "Why buy this product" section
func (ai *AIGenerator) GenerateWhyBuy(productID uuid.UUID) (*WhyBuyReasons, error) {
	ctx := ai.getProductContext(productID)
	if ctx == nil {
		return nil, fmt.Errorf("product not found")
	}

	systemPrompt := `Si marketingový expert. Vygeneruj 4-5 presvedčivých dôvodov prečo si kúpiť produkt.

PRAVIDLÁ:
- Odpovedaj po SLOVENSKY
- Každý dôvod má ikonu (emoji), krátky titul a krátky text
- Zameraj sa na benefity pre zákazníka
- Buď konkrétny, nie generický

FORMÁT (JSON):
{
  "reasons": [
    {"icon": "✅", "title": "Kvalita", "text": "Vysokokvalitné materiály..."},
    {"icon": "🚚", "title": "Rýchle doručenie", "text": "Do 24 hodín..."}
  ]
}

Vráť IBA JSON.`

	userMessage := fmt.Sprintf(`Dôvody na kúpu:

Produkt: %s
Kategória: %s
Značka: %s
Cena: %.2f €`, ctx.Title, ctx.Category, ctx.Brand, ctx.Price)

	response, err := ai.sendMessage(systemPrompt, userMessage)
	if err != nil {
		return nil, err
	}

	return ai.parseWhyBuyResponse(response)
}

// ProductAlternatives result
type ProductAlternatives struct {
	Alternatives []Alternative `json:"alternatives"`
}

type Alternative struct {
	ProductID   uuid.UUID `json:"product_id"`
	Title       string    `json:"title"`
	Price       float64   `json:"price"`
	Reason      string    `json:"reason"`
	CompareType string    `json:"compare_type"` // cheaper, premium, similar
}

// FindAlternatives finds and explains alternative products
func (ai *AIGenerator) FindAlternatives(productID uuid.UUID) (*ProductAlternatives, error) {
	ctx := ai.getProductContext(productID)
	if ctx == nil {
		return nil, fmt.Errorf("product not found")
	}

	// Get similar products from database
	var alts []Alternative
	rows, err := ai.pool.Query(ai.ctx, `
		SELECT p.id, p.title, p.price_min
		FROM products p
		WHERE p.category_id = (SELECT category_id FROM products WHERE id = $1)
		AND p.id != $1
		AND p.is_active = true
		ORDER BY 
			CASE 
				WHEN p.price_min < (SELECT price_min FROM products WHERE id = $1) * 0.8 THEN 1
				WHEN p.price_min > (SELECT price_min FROM products WHERE id = $1) * 1.2 THEN 2
				ELSE 3
			END,
			p.offer_count DESC
		LIMIT 6
	`, productID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var alt Alternative
		rows.Scan(&alt.ProductID, &alt.Title, &alt.Price)
		
		// Determine compare type
		if alt.Price < ctx.Price*0.8 {
			alt.CompareType = "cheaper"
			alt.Reason = "Cenovo výhodnejšia alternatíva"
		} else if alt.Price > ctx.Price*1.2 {
			alt.CompareType = "premium"
			alt.Reason = "Prémiová alternatíva s lepšími vlastnosťami"
		} else {
			alt.CompareType = "similar"
			alt.Reason = "Podobný produkt v rovnakej cenovej kategórii"
		}
		
		alts = append(alts, alt)
	}

	return &ProductAlternatives{Alternatives: alts}, nil
}

// ProductComparison result
type ProductComparison struct {
	Products   []ComparedProduct `json:"products"`
	Comparison string            `json:"comparison"` // AI generated comparison text
	Winner     *uuid.UUID        `json:"winner"`
}

type ComparedProduct struct {
	ID    uuid.UUID `json:"id"`
	Title string    `json:"title"`
	Price float64   `json:"price"`
}

// CompareProducts creates AI comparison between products
func (ai *AIGenerator) CompareProducts(productIDs []uuid.UUID) (*ProductComparison, error) {
	if len(productIDs) < 2 {
		return nil, fmt.Errorf("need at least 2 products to compare")
	}
	if len(productIDs) > 5 {
		productIDs = productIDs[:5]
	}

	var products []ComparedProduct
	var contextParts []string

	for _, pid := range productIDs {
		ctx := ai.getProductContext(pid)
		if ctx != nil {
			products = append(products, ComparedProduct{
				ID:    pid,
				Title: ctx.Title,
				Price: ctx.Price,
			})
			contextParts = append(contextParts, fmt.Sprintf("- %s (%.2f €): %s, %s", ctx.Title, ctx.Price, ctx.Brand, ctx.Category))
		}
	}

	if len(products) < 2 {
		return nil, fmt.Errorf("not enough valid products")
	}

	systemPrompt := `Si expert na porovnávanie produktov. Vytvor stručné ale užitočné porovnanie.

PRAVIDLÁ:
- Odpovedaj po SLOVENSKY
- Max 200 slov
- Buď objektívny
- Zvýrazni kľúčové rozdiely
- Odporuč najlepšiu voľbu pre rôzne použitie

Vráť IBA text porovnania (nie JSON).`

	userMessage := fmt.Sprintf(`Porovnaj tieto produkty:

%s`, strings.Join(contextParts, "\n"))

	comparison, err := ai.sendMessage(systemPrompt, userMessage)
	if err != nil {
		return nil, err
	}

	return &ProductComparison{
		Products:   products,
		Comparison: comparison,
	}, nil
}

// ImproveDescription improves existing description
func (ai *AIGenerator) ImproveDescription(productID uuid.UUID, improvements []string) (string, error) {
	ctx := ai.getProductContext(productID)
	if ctx == nil {
		return "", fmt.Errorf("product not found")
	}

	if ctx.Description == "" {
		result, err := ai.GenerateDescription(productID, "professional", "medium")
		if err != nil {
			return "", err
		}
		return result.FullDescription, nil
	}

	improvementsList := []string{}
	for _, imp := range improvements {
		switch imp {
		case "seo":
			improvementsList = append(improvementsList, "Pridaj SEO kľúčové slová")
		case "benefits":
			improvementsList = append(improvementsList, "Zdôrazni výhody pre zákazníka")
		case "structure":
			improvementsList = append(improvementsList, "Zlepši štruktúru a čitateľnosť")
		case "cta":
			improvementsList = append(improvementsList, "Pridaj výzvu k akcii")
		}
	}

	if len(improvementsList) == 0 {
		improvementsList = append(improvementsList, "Všeobecne zlepši kvalitu")
	}

	systemPrompt := fmt.Sprintf(`Si expert copywriter. Vylepši existujúci popis produktu.

ÚLOHA: %s

PRAVIDLÁ:
- Odpovedaj po SLOVENSKY
- Zachovaj pravdivé informácie
- Používaj HTML formátovanie
- Vráť IBA vylepšený HTML popis`, strings.Join(improvementsList, ", "))

	userMessage := fmt.Sprintf(`PÔVODNÝ POPIS:
%s

PRODUKT: %s
KATEGÓRIA: %s
ZNAČKA: %s`, ctx.Description, ctx.Title, ctx.Category, ctx.Brand)

	return ai.sendMessage(systemPrompt, userMessage)
}

// Helper methods

func (ai *AIGenerator) getProductContext(productID uuid.UUID) *ProductContext {
	var ctx ProductContext
	var categoryName, brandName *string

	err := ai.pool.QueryRow(ai.ctx, `
		SELECT p.title, c.name, b.name, p.price_min, p.description, p.ean
		FROM products p
		LEFT JOIN categories c ON p.category_id = c.id
		LEFT JOIN brands b ON p.brand_id = b.id
		WHERE p.id = $1
	`, productID).Scan(&ctx.Title, &categoryName, &brandName, &ctx.Price, &ctx.Description, &ctx.EAN)

	if err != nil {
		return nil
	}

	if categoryName != nil {
		ctx.Category = *categoryName
	}
	if brandName != nil {
		ctx.Brand = *brandName
	}

	// Get attributes
	ctx.Attributes = make(map[string]string)
	rows, err := ai.pool.Query(ai.ctx, `
		SELECT a.name, pav.value
		FROM product_attribute_values pav
		JOIN attributes a ON pav.attribute_id = a.id
		WHERE pav.product_id = $1
	`, productID)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var name, value string
			rows.Scan(&name, &value)
			ctx.Attributes[name] = value
		}
	}

	return &ctx
}

func (ai *AIGenerator) sendMessage(systemPrompt, userMessage string) (string, error) {
	if ai.apiKey == "" {
		return "", fmt.Errorf("API key not configured")
	}

	requestBody := map[string]interface{}{
		"model":      "claude-sonnet-4-20250514",
		"max_tokens": 2048,
		"system":     systemPrompt,
		"messages": []map[string]string{
			{"role": "user", "content": userMessage},
		},
	}

	jsonBody, _ := json.Marshal(requestBody)

	req, _ := http.NewRequest("POST", ai.apiURL, bytes.NewBuffer(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", ai.apiKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	client := &http.Client{Timeout: 60 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != 200 {
		log.Error().Int("status", resp.StatusCode).Str("body", string(body)).Msg("AI API error")
		return "", fmt.Errorf("API error: %d", resp.StatusCode)
	}

	var result struct {
		Content []struct {
			Text string `json:"text"`
		} `json:"content"`
	}

	if err := json.Unmarshal(body, &result); err != nil {
		return "", err
	}

	if len(result.Content) > 0 {
		return result.Content[0].Text, nil
	}

	return "", fmt.Errorf("empty response")
}

func (ai *AIGenerator) parseDescriptionResponse(response string) (*GeneratedDescription, error) {
	response = strings.TrimSpace(response)
	response = strings.TrimPrefix(response, "```json")
	response = strings.TrimPrefix(response, "```")
	response = strings.TrimSuffix(response, "```")

	var result GeneratedDescription
	if err := json.Unmarshal([]byte(response), &result); err != nil {
		// Try to find JSON in response
		start := strings.Index(response, "{")
		end := strings.LastIndex(response, "}")
		if start >= 0 && end > start {
			if err := json.Unmarshal([]byte(response[start:end+1]), &result); err != nil {
				return nil, err
			}
		} else {
			return nil, err
		}
	}

	return &result, nil
}

func (ai *AIGenerator) parseFAQResponse(response string) (*GeneratedFAQ, error) {
	response = strings.TrimSpace(response)
	response = strings.TrimPrefix(response, "```json")
	response = strings.TrimSuffix(response, "```")

	var result GeneratedFAQ
	if err := json.Unmarshal([]byte(response), &result); err != nil {
		start := strings.Index(response, "{")
		end := strings.LastIndex(response, "}")
		if start >= 0 && end > start {
			json.Unmarshal([]byte(response[start:end+1]), &result)
		}
	}

	return &result, nil
}

func (ai *AIGenerator) parseWhyBuyResponse(response string) (*WhyBuyReasons, error) {
	response = strings.TrimSpace(response)
	response = strings.TrimPrefix(response, "```json")
	response = strings.TrimSuffix(response, "```")

	var result WhyBuyReasons
	if err := json.Unmarshal([]byte(response), &result); err != nil {
		start := strings.Index(response, "{")
		end := strings.LastIndex(response, "}")
		if start >= 0 && end > start {
			json.Unmarshal([]byte(response[start:end+1]), &result)
		}
	}

	return &result, nil
}
