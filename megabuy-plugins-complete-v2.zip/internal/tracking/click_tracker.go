package tracking

import (
	"context"
	"crypto/sha256"
	"fmt"
	"net"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog/log"
)

// ClickTracker handles CPC click tracking
type ClickTracker struct {
	pool *pgxpool.Pool
	ctx  context.Context
}

func NewClickTracker(pool *pgxpool.Pool) *ClickTracker {
	return &ClickTracker{pool: pool, ctx: context.Background()}
}

// TrackClickRequest for incoming click
type TrackClickRequest struct {
	OfferID   uuid.UUID
	ProductID uuid.UUID
	VendorID  uuid.UUID
	UserID    *uuid.UUID
	IP        string
	UserAgent string
	Referer   string
	ClickType string // affiliate, direct, comparison
	UTMSource string
	UTMMedium string
	UTMCampaign string
}

// TrackClickResponse result
type TrackClickResponse struct {
	ClickID     uuid.UUID `json:"click_id"`
	RedirectURL string    `json:"redirect_url"`
	IsDuplicate bool      `json:"is_duplicate"`
	Cost        float64   `json:"cost"`
	IsCharged   bool      `json:"is_charged"`
}

// TrackClick records click and handles CPC billing
func (ct *ClickTracker) TrackClick(req TrackClickRequest) (*TrackClickResponse, error) {
	// Get offer and vendor details
	var offerURL string
	var cpcRate float64
	var displayMode string
	var creditBalance float64
	var vendorID uuid.UUID
	var productID uuid.UUID

	err := ct.pool.QueryRow(ct.ctx, `
		SELECT o.url, o.product_id, o.vendor_id,
			COALESCE(o.cpc_rate, v.cpc_rate, 0.05) as cpc_rate,
			v.display_mode, v.credit_balance
		FROM offers o
		JOIN vendors v ON o.vendor_id = v.id
		WHERE o.id = $1 AND o.is_active = true
	`, req.OfferID).Scan(&offerURL, &productID, &vendorID, &cpcRate, &displayMode, &creditBalance)

	if err != nil {
		return nil, fmt.Errorf("offer not found: %w", err)
	}

	// Hash IP for privacy
	ipHash := hashIP(req.IP)

	// Deduplicate (5 minute window)
	var existingClickID uuid.UUID
	err = ct.pool.QueryRow(ct.ctx, `
		SELECT id FROM clicks 
		WHERE offer_id = $1 AND ip_hash = $2 AND created_at > NOW() - INTERVAL '5 minutes'
		LIMIT 1
	`, req.OfferID, ipHash).Scan(&existingClickID)

	if err == nil {
		return &TrackClickResponse{
			ClickID:     existingClickID,
			RedirectURL: offerURL,
			IsDuplicate: true,
			Cost:        0,
		}, nil
	}

	// Calculate cost based on display mode
	var cost float64
	var isCharged bool

	switch displayMode {
	case "CPC", "PAID":
		if creditBalance > 0 {
			cost = cpcRate
			isCharged = true
		}
	case "PREMIUM":
		cost = 0
		isCharged = false
	default: // FREE
		cost = 0
		isCharged = false
	}

	// Record click
	clickID := uuid.New()
	_, err = ct.pool.Exec(ct.ctx, `
		INSERT INTO clicks (
			id, offer_id, product_id, vendor_id, user_id, ip_hash, 
			user_agent, referer, cost, is_charged, created_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
	`, clickID, req.OfferID, productID, vendorID, req.UserID, ipHash,
		truncate(req.UserAgent, 500), truncate(req.Referer, 500), cost, isCharged)

	if err != nil {
		log.Error().Err(err).Msg("Failed to record click")
	}

	// Charge vendor if applicable
	if isCharged && cost > 0 {
		ct.chargeVendor(vendorID, cost, clickID)
	}

	// Update click counts
	ct.pool.Exec(ct.ctx, `UPDATE offers SET click_count = click_count + 1 WHERE id = $1`, req.OfferID)
	ct.pool.Exec(ct.ctx, `UPDATE products SET click_count = click_count + 1 WHERE id = $1`, productID)

	return &TrackClickResponse{
		ClickID:     clickID,
		RedirectURL: offerURL,
		IsDuplicate: false,
		Cost:        cost,
		IsCharged:   isCharged,
	}, nil
}

// chargeVendor deducts CPC from vendor credit
func (ct *ClickTracker) chargeVendor(vendorID uuid.UUID, amount float64, clickID uuid.UUID) error {
	tx, err := ct.pool.Begin(ct.ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ct.ctx)

	var newBalance float64
	err = tx.QueryRow(ct.ctx, `
		UPDATE vendors 
		SET credit_balance = credit_balance - $1, updated_at = NOW()
		WHERE id = $2
		RETURNING credit_balance
	`, amount, vendorID).Scan(&newBalance)

	if err != nil {
		return err
	}

	// Log transaction
	_, err = tx.Exec(ct.ctx, `
		INSERT INTO transactions (id, vendor_id, type, amount, balance, description, reference_id, created_at)
		VALUES ($1, $2, 'DEBIT', $3, $4, 'CPC Click', $5, NOW())
	`, uuid.New(), vendorID, amount, newBalance, clickID.String())

	if err != nil {
		return err
	}

	// Switch to FREE if depleted
	if newBalance <= 0 {
		tx.Exec(ct.ctx, `UPDATE vendors SET display_mode = 'FREE' WHERE id = $1`, vendorID)
		log.Info().Str("vendor", vendorID.String()).Msg("Vendor switched to FREE due to depleted credits")
	} else if newBalance < 5 {
		log.Warn().Str("vendor", vendorID.String()).Float64("balance", newBalance).Msg("Vendor credit balance low")
	}

	return tx.Commit(ct.ctx)
}

// AddCredit adds credit to vendor
func (ct *ClickTracker) AddCredit(vendorID uuid.UUID, amount float64, bonus float64, paymentMethod string, description string) error {
	tx, err := ct.pool.Begin(ct.ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ct.ctx)

	totalCredit := amount + bonus

	var newBalance float64
	err = tx.QueryRow(ct.ctx, `
		UPDATE vendors 
		SET credit_balance = credit_balance + $1, updated_at = NOW()
		WHERE id = $2
		RETURNING credit_balance
	`, totalCredit, vendorID).Scan(&newBalance)

	if err != nil {
		return err
	}

	// Enable CPC mode if was FREE
	if newBalance > 0 {
		tx.Exec(ct.ctx, `UPDATE vendors SET display_mode = 'CPC' WHERE id = $1 AND display_mode = 'FREE'`, vendorID)
	}

	// Log topup transaction
	_, err = tx.Exec(ct.ctx, `
		INSERT INTO transactions (id, vendor_id, type, amount, balance, description, created_at)
		VALUES ($1, $2, 'CREDIT', $3, $4, $5, NOW())
	`, uuid.New(), vendorID, amount, newBalance-bonus, fmt.Sprintf("Dobíjanie kreditu (%s)", paymentMethod))

	if err != nil {
		return err
	}

	// Log bonus if any
	if bonus > 0 {
		_, err = tx.Exec(ct.ctx, `
			INSERT INTO transactions (id, vendor_id, type, amount, balance, description, created_at)
			VALUES ($1, $2, 'CREDIT', $3, $4, $5, NOW())
		`, uuid.New(), vendorID, bonus, newBalance, fmt.Sprintf("Bonus za dobíjanie %.0f €", amount))
		if err != nil {
			return err
		}
	}

	log.Info().
		Str("vendor", vendorID.String()).
		Float64("amount", amount).
		Float64("bonus", bonus).
		Float64("new_balance", newBalance).
		Msg("Credit added to vendor")

	return tx.Commit(ct.ctx)
}

// VendorStats for vendor dashboard
type VendorStats struct {
	VendorID       uuid.UUID      `json:"vendor_id"`
	TotalClicks    int            `json:"total_clicks"`
	ChargedClicks  int            `json:"charged_clicks"`
	TotalCost      float64        `json:"total_cost"`
	AvgCPC         float64        `json:"avg_cpc"`
	UniqueProducts int            `json:"unique_products"`
	Conversions    int            `json:"conversions"`
	ConversionRate float64        `json:"conversion_rate"`
	Daily          []DailyStats   `json:"daily"`
	TopProducts    []ProductStats `json:"top_products"`
	CreditBalance  float64        `json:"credit_balance"`
	DisplayMode    string         `json:"display_mode"`
	EstimatedClicks int           `json:"estimated_clicks"`
}

type DailyStats struct {
	Date   time.Time `json:"date"`
	Clicks int       `json:"clicks"`
	Cost   float64   `json:"cost"`
}

type ProductStats struct {
	ID     uuid.UUID `json:"id"`
	Title  string    `json:"title"`
	Slug   string    `json:"slug"`
	Clicks int       `json:"clicks"`
	Cost   float64   `json:"cost"`
}

// GetVendorStats returns detailed vendor statistics
func (ct *ClickTracker) GetVendorStats(vendorID uuid.UUID, period string) (*VendorStats, error) {
	stats := &VendorStats{VendorID: vendorID}

	// Period calculation
	var from time.Time
	switch period {
	case "7days":
		from = time.Now().AddDate(0, 0, -7)
	case "30days":
		from = time.Now().AddDate(0, 0, -30)
	case "90days":
		from = time.Now().AddDate(0, 0, -90)
	default:
		from = time.Now().AddDate(0, 0, -30)
	}
	to := time.Now()

	// Get vendor info
	ct.pool.QueryRow(ct.ctx, `
		SELECT credit_balance, display_mode FROM vendors WHERE id = $1
	`, vendorID).Scan(&stats.CreditBalance, &stats.DisplayMode)

	// Total clicks and cost
	ct.pool.QueryRow(ct.ctx, `
		SELECT COUNT(*), COUNT(*) FILTER (WHERE is_charged = true), COALESCE(SUM(cost), 0)
		FROM clicks
		WHERE vendor_id = $1 AND created_at BETWEEN $2 AND $3
	`, vendorID, from, to).Scan(&stats.TotalClicks, &stats.ChargedClicks, &stats.TotalCost)

	// Avg CPC
	if stats.ChargedClicks > 0 {
		stats.AvgCPC = stats.TotalCost / float64(stats.ChargedClicks)
	}

	// Unique products
	ct.pool.QueryRow(ct.ctx, `
		SELECT COUNT(DISTINCT product_id)
		FROM clicks
		WHERE vendor_id = $1 AND created_at BETWEEN $2 AND $3
	`, vendorID, from, to).Scan(&stats.UniqueProducts)

	// Estimated remaining clicks
	if stats.AvgCPC > 0 {
		stats.EstimatedClicks = int(stats.CreditBalance / stats.AvgCPC)
	}

	// Daily breakdown
	rows, err := ct.pool.Query(ct.ctx, `
		SELECT DATE(created_at) as date, COUNT(*) as clicks, COALESCE(SUM(cost), 0) as cost
		FROM clicks
		WHERE vendor_id = $1 AND created_at BETWEEN $2 AND $3
		GROUP BY DATE(created_at)
		ORDER BY date DESC
		LIMIT 30
	`, vendorID, from, to)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var day DailyStats
			rows.Scan(&day.Date, &day.Clicks, &day.Cost)
			stats.Daily = append(stats.Daily, day)
		}
	}

	// Top products
	rows, err = ct.pool.Query(ct.ctx, `
		SELECT p.id, p.title, p.slug, COUNT(c.id) as clicks, COALESCE(SUM(c.cost), 0) as cost
		FROM clicks c
		JOIN products p ON c.product_id = p.id
		WHERE c.vendor_id = $1 AND c.created_at BETWEEN $2 AND $3
		GROUP BY p.id, p.title, p.slug
		ORDER BY clicks DESC
		LIMIT 10
	`, vendorID, from, to)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var prod ProductStats
			rows.Scan(&prod.ID, &prod.Title, &prod.Slug, &prod.Clicks, &prod.Cost)
			stats.TopProducts = append(stats.TopProducts, prod)
		}
	}

	return stats, nil
}

// Transaction history
type Transaction struct {
	ID          uuid.UUID `json:"id"`
	Type        string    `json:"type"` // CREDIT, DEBIT, BONUS, REFUND
	Amount      float64   `json:"amount"`
	Balance     float64   `json:"balance"`
	Description string    `json:"description"`
	ReferenceID string    `json:"reference_id"`
	CreatedAt   time.Time `json:"created_at"`
}

// GetTransactionHistory returns vendor transactions
func (ct *ClickTracker) GetTransactionHistory(vendorID uuid.UUID, limit int) ([]Transaction, error) {
	var transactions []Transaction

	rows, err := ct.pool.Query(ct.ctx, `
		SELECT id, type, amount, balance, description, COALESCE(reference_id, ''), created_at
		FROM transactions
		WHERE vendor_id = $1
		ORDER BY created_at DESC
		LIMIT $2
	`, vendorID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var t Transaction
		rows.Scan(&t.ID, &t.Type, &t.Amount, &t.Balance, &t.Description, &t.ReferenceID, &t.CreatedAt)
		transactions = append(transactions, t)
	}

	return transactions, nil
}

// UpdateDisplayMode changes vendor display mode
func (ct *ClickTracker) UpdateDisplayMode(vendorID uuid.UUID, mode string) error {
	// Validate mode
	validModes := map[string]bool{"FREE": true, "CPC": true, "PAID": true, "PREMIUM": true}
	if !validModes[mode] {
		return fmt.Errorf("invalid display mode: %s", mode)
	}

	// Check credit for CPC mode
	if mode == "CPC" || mode == "PAID" {
		var balance float64
		ct.pool.QueryRow(ct.ctx, `SELECT credit_balance FROM vendors WHERE id = $1`, vendorID).Scan(&balance)
		if balance <= 0 {
			return fmt.Errorf("insufficient credit for CPC mode")
		}
	}

	_, err := ct.pool.Exec(ct.ctx, `
		UPDATE vendors SET display_mode = $1, updated_at = NOW() WHERE id = $2
	`, mode, vendorID)

	return err
}

// Credit packages
type CreditPackage struct {
	Amount  float64 `json:"amount"`
	Bonus   float64 `json:"bonus"`
	Percent int     `json:"percent"`
}

// GetCreditPackages returns available packages
func (ct *ClickTracker) GetCreditPackages() []CreditPackage {
	return []CreditPackage{
		{Amount: 10, Bonus: 0, Percent: 0},
		{Amount: 25, Bonus: 2, Percent: 8},
		{Amount: 50, Bonus: 5, Percent: 10},
		{Amount: 100, Bonus: 15, Percent: 15},
		{Amount: 250, Bonus: 50, Percent: 20},
		{Amount: 500, Bonus: 125, Percent: 25},
	}
}

// Helpers
func hashIP(ip string) string {
	host, _, err := net.SplitHostPort(ip)
	if err != nil {
		host = ip
	}
	hash := sha256.Sum256([]byte(host + "megabuy-salt-2024"))
	return fmt.Sprintf("%x", hash[:16])
}

func truncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen]
}
