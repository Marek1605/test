package importer

import (
	"context"
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"regexp"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// VendorFeedImporter handles vendor-specific feed imports
// Creates affiliate offers linked to master products
type VendorFeedImporter struct {
	pool         *pgxpool.Pool
	baseImporter *FeedImporter
}

func NewVendorFeedImporter(pool *pgxpool.Pool) *VendorFeedImporter {
	return &VendorFeedImporter{
		pool:         pool,
		baseImporter: NewFeedImporter(pool),
	}
}

// MasterProduct represents a master product
type MasterProduct struct {
	ID          uuid.UUID `json:"id"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	EAN         string    `json:"ean"`
	SKU         string    `json:"sku"`
	CategoryID  uuid.UUID `json:"category_id"`
	BrandID     uuid.UUID `json:"brand_id"`
	ImageURL    string    `json:"image_url"`
	PriceMin    float64   `json:"price_min"`
	PriceMax    float64   `json:"price_max"`
	IsMaster    bool      `json:"is_master"`
}

// AffiliateOffer represents vendor's offer for a product
type AffiliateOffer struct {
	ID            uuid.UUID  `json:"id"`
	MasterID      uuid.UUID  `json:"master_id"` // Master product ID
	VendorID      uuid.UUID  `json:"vendor_id"`
	FeedID        uuid.UUID  `json:"feed_id"`
	ExternalID    string     `json:"external_id"`
	SKU           string     `json:"sku"`
	EAN           string     `json:"ean"`
	Price         float64    `json:"price"`
	OriginalPrice float64    `json:"original_price"`
	URL           string     `json:"url"` // Affiliate URL
	ImageURL      string     `json:"image_url"`
	InStock       bool       `json:"in_stock"`
	StockCount    int        `json:"stock_count"`
	DeliveryDays  int        `json:"delivery_days"`
	DeliveryPrice float64    `json:"delivery_price"`
	IsActive      bool       `json:"is_active"`
	Checksum      string     `json:"checksum"`
}

// VendorImportResult extends ImportResult
type VendorImportResult struct {
	ImportResult
	MastersCreated   int `json:"masters_created"`
	OffersCreated    int `json:"offers_created"`
	OffersUpdated    int `json:"offers_updated"`
	MatchedByEAN     int `json:"matched_by_ean"`
	MatchedBySKU     int `json:"matched_by_sku"`
	MatchedByTitle   int `json:"matched_by_title"`
	UnmatchedSkipped int `json:"unmatched_skipped"`
}

// RunVendorImport runs feed import for vendor
func (v *VendorFeedImporter) RunVendorImport(feedID uuid.UUID) (*VendorImportResult, error) {
	ctx := context.Background()

	// Get feed info
	var vendorID uuid.UUID
	var feedURL, feedType string
	var deactivateMissing bool

	err := v.pool.QueryRow(ctx, `
		SELECT vendor_id, url, type, deactivate_missing 
		FROM feeds WHERE id = $1
	`, feedID).Scan(&vendorID, &feedURL, &feedType, &deactivateMissing)
	if err != nil {
		return nil, fmt.Errorf("feed not found: %w", err)
	}

	// Create history record
	historyID := uuid.New()
	v.pool.Exec(ctx, `
		INSERT INTO feed_history (id, feed_id, status, started_at)
		VALUES ($1, $2, 'running', NOW())
	`, historyID, feedID)

	result := &VendorImportResult{}

	// Download and parse feed using base importer
	preview := v.baseImporter.GetPreview(feedURL, feedType, 0) // 0 = all items
	if preview.Error != "" {
		v.updateHistory(historyID, "failed", result, preview.Error)
		return nil, fmt.Errorf(preview.Error)
	}

	result.TotalItems = preview.TotalItems
	processedIDs := make(map[string]bool)

	// Process each item
	for _, item := range preview.Items {
		itemResult := v.processVendorItem(ctx, item, vendorID, feedID)
		
		switch itemResult {
		case "master_created":
			result.MastersCreated++
			result.NewProducts++
		case "offer_created":
			result.OffersCreated++
		case "offer_updated":
			result.OffersUpdated++
			result.UpdatedProducts++
		case "matched_ean":
			result.MatchedByEAN++
		case "matched_sku":
			result.MatchedBySKU++
		case "matched_title":
			result.MatchedByTitle++
		case "skipped":
			result.UnmatchedSkipped++
		case "error":
			result.Errors++
		}

		// Track processed external IDs
		if item.ID != "" {
			processedIDs[item.ID] = true
		}
	}

	// Deactivate missing offers
	if deactivateMissing {
		result.DeletedProducts = v.deactivateMissingOffers(ctx, feedID, processedIDs)
	}

	v.updateHistory(historyID, "completed", result, "")
	return result, nil
}

// processVendorItem processes single feed item for vendor
func (v *VendorFeedImporter) processVendorItem(ctx context.Context, item FeedItem, vendorID, feedID uuid.UUID) string {
	// Generate checksum for change detection
	checksum := v.generateChecksum(item)

	// Check if offer exists
	var existingOfferID uuid.UUID
	var existingChecksum string
	err := v.pool.QueryRow(ctx, `
		SELECT id, checksum FROM offers 
		WHERE feed_id = $1 AND external_id = $2
	`, feedID, item.ID).Scan(&existingOfferID, &existingChecksum)

	if err == nil && existingChecksum == checksum {
		// No changes
		return "skipped"
	}

	// Try to find master product
	masterID, matchType := v.findMasterProduct(ctx, item)

	if masterID == uuid.Nil {
		// Create new master product
		masterID = v.createMasterProduct(ctx, item)
		if masterID == uuid.Nil {
			return "error"
		}
		
		// Create offer for new master
		v.createOffer(ctx, masterID, item, vendorID, feedID, checksum)
		return "master_created"
	}

	// Master exists - create or update offer
	if existingOfferID != uuid.Nil {
		v.updateOffer(ctx, existingOfferID, masterID, item, checksum)
		return "offer_updated"
	}

	v.createOffer(ctx, masterID, item, vendorID, feedID, checksum)
	
	switch matchType {
	case "ean":
		return "matched_ean"
	case "sku":
		return "matched_sku"
	case "title":
		return "matched_title"
	}
	return "offer_created"
}

// findMasterProduct finds existing master product
func (v *VendorFeedImporter) findMasterProduct(ctx context.Context, item FeedItem) (uuid.UUID, string) {
	var masterID uuid.UUID

	// 1. Try EAN match (highest priority)
	if item.EAN != "" {
		err := v.pool.QueryRow(ctx, `
			SELECT id FROM products WHERE ean = $1 LIMIT 1
		`, item.EAN).Scan(&masterID)
		if err == nil {
			return masterID, "ean"
		}
	}

	// 2. Try SKU match
	if item.SKU != "" {
		err := v.pool.QueryRow(ctx, `
			SELECT id FROM products WHERE sku = $1 LIMIT 1
		`, item.SKU).Scan(&masterID)
		if err == nil {
			return masterID, "sku"
		}
	}

	// 3. Try title match (fuzzy)
	if item.Title != "" {
		normalizedTitle := v.normalizeTitle(item.Title)
		err := v.pool.QueryRow(ctx, `
			SELECT id FROM products 
			WHERE LOWER(REGEXP_REPLACE(title, '[^a-zA-Z0-9]', '', 'g')) = $1
			LIMIT 1
		`, normalizedTitle).Scan(&masterID)
		if err == nil {
			return masterID, "title"
		}
	}

	return uuid.Nil, ""
}

// createMasterProduct creates new master product
func (v *VendorFeedImporter) createMasterProduct(ctx context.Context, item FeedItem) uuid.UUID {
	masterID := uuid.New()
	slug := v.generateSlug(item.Title)

	// Find or create category
	var categoryID *uuid.UUID
	if item.Category != "" {
		catID := v.findOrCreateCategory(ctx, item.Category)
		categoryID = &catID
	}

	// Find or create brand
	var brandID *uuid.UUID
	if item.Brand != "" {
		bID := v.findOrCreateBrand(ctx, item.Brand)
		brandID = &bID
	}

	_, err := v.pool.Exec(ctx, `
		INSERT INTO products (
			id, title, slug, description, ean, sku, image_url,
			category_id, brand_id, price_min, price_max, is_master,
			created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $10, true, NOW(), NOW())
	`, masterID, item.Title, slug, item.Description, item.EAN, item.SKU,
		item.ImageURL, categoryID, brandID, item.Price)

	if err != nil {
		return uuid.Nil
	}

	return masterID
}

// createOffer creates new vendor offer
func (v *VendorFeedImporter) createOffer(ctx context.Context, masterID uuid.UUID, item FeedItem, vendorID, feedID uuid.UUID, checksum string) {
	offerID := uuid.New()

	v.pool.Exec(ctx, `
		INSERT INTO offers (
			id, product_id, vendor_id, feed_id, external_id, sku, ean,
			price, original_price, url, image_url, in_stock, stock_count,
			delivery_days, delivery_price, is_active, checksum, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, true, $16, NOW(), NOW())
	`, offerID, masterID, vendorID, feedID, item.ID, item.SKU, item.EAN,
		item.Price, item.OriginalPrice, item.URL, item.ImageURL, item.InStock, item.Stock,
		item.DeliveryDays, item.DeliveryPrice, checksum)

	// Update master product prices
	v.updateMasterPrices(ctx, masterID)
}

// updateOffer updates existing offer
func (v *VendorFeedImporter) updateOffer(ctx context.Context, offerID, masterID uuid.UUID, item FeedItem, checksum string) {
	v.pool.Exec(ctx, `
		UPDATE offers SET
			product_id = $1, price = $2, original_price = $3, url = $4,
			image_url = $5, in_stock = $6, stock_count = $7,
			delivery_days = $8, delivery_price = $9, checksum = $10,
			is_active = true, updated_at = NOW()
		WHERE id = $11
	`, masterID, item.Price, item.OriginalPrice, item.URL, item.ImageURL,
		item.InStock, item.Stock, item.DeliveryDays, item.DeliveryPrice, checksum, offerID)

	v.updateMasterPrices(ctx, masterID)
}

// updateMasterPrices updates min/max prices on master product
func (v *VendorFeedImporter) updateMasterPrices(ctx context.Context, masterID uuid.UUID) {
	v.pool.Exec(ctx, `
		UPDATE products SET
			price_min = (SELECT MIN(price) FROM offers WHERE product_id = $1 AND is_active = true),
			price_max = (SELECT MAX(price) FROM offers WHERE product_id = $1 AND is_active = true),
			offer_count = (SELECT COUNT(*) FROM offers WHERE product_id = $1 AND is_active = true),
			updated_at = NOW()
		WHERE id = $1
	`, masterID)
}

// deactivateMissingOffers deactivates offers not in current feed
func (v *VendorFeedImporter) deactivateMissingOffers(ctx context.Context, feedID uuid.UUID, processedIDs map[string]bool) int {
	// Get all active offers for this feed
	rows, _ := v.pool.Query(ctx, `
		SELECT id, external_id FROM offers WHERE feed_id = $1 AND is_active = true
	`, feedID)
	defer rows.Close()

	var toDeactivate []uuid.UUID
	for rows.Next() {
		var id uuid.UUID
		var externalID string
		rows.Scan(&id, &externalID)
		if !processedIDs[externalID] {
			toDeactivate = append(toDeactivate, id)
		}
	}

	for _, id := range toDeactivate {
		v.pool.Exec(ctx, `UPDATE offers SET is_active = false, updated_at = NOW() WHERE id = $1`, id)
	}

	return len(toDeactivate)
}

// Helper functions
func (v *VendorFeedImporter) generateChecksum(item FeedItem) string {
	data := fmt.Sprintf("%s|%s|%.2f|%.2f|%s|%v|%d",
		item.Title, item.EAN, item.Price, item.OriginalPrice,
		item.URL, item.InStock, item.Stock)
	hash := md5.Sum([]byte(data))
	return hex.EncodeToString(hash[:])
}

func (v *VendorFeedImporter) normalizeTitle(title string) string {
	reg := regexp.MustCompile("[^a-zA-Z0-9]+")
	return strings.ToLower(reg.ReplaceAllString(title, ""))
}

func (v *VendorFeedImporter) generateSlug(title string) string {
	slug := strings.ToLower(title)
	reg := regexp.MustCompile("[^a-z0-9]+")
	slug = reg.ReplaceAllString(slug, "-")
	slug = strings.Trim(slug, "-")
	if len(slug) > 100 {
		slug = slug[:100]
	}
	return slug
}

func (v *VendorFeedImporter) findOrCreateCategory(ctx context.Context, categoryPath string) uuid.UUID {
	parts := strings.Split(categoryPath, "|")
	if len(parts) == 0 {
		return uuid.Nil
	}

	categoryName := strings.TrimSpace(parts[len(parts)-1])
	slug := v.generateSlug(categoryName)

	var catID uuid.UUID
	err := v.pool.QueryRow(ctx, `SELECT id FROM categories WHERE slug = $1`, slug).Scan(&catID)
	if err == nil {
		return catID
	}

	catID = uuid.New()
	v.pool.Exec(ctx, `
		INSERT INTO categories (id, name, slug, created_at) VALUES ($1, $2, $3, NOW())
	`, catID, categoryName, slug)

	return catID
}

func (v *VendorFeedImporter) findOrCreateBrand(ctx context.Context, brandName string) uuid.UUID {
	slug := v.generateSlug(brandName)

	var brandID uuid.UUID
	err := v.pool.QueryRow(ctx, `SELECT id FROM brands WHERE slug = $1`, slug).Scan(&brandID)
	if err == nil {
		return brandID
	}

	brandID = uuid.New()
	v.pool.Exec(ctx, `
		INSERT INTO brands (id, name, slug, created_at) VALUES ($1, $2, $3, NOW())
	`, brandID, brandName, slug)

	return brandID
}

func (v *VendorFeedImporter) updateHistory(historyID uuid.UUID, status string, result *VendorImportResult, errorMsg string) {
	v.pool.Exec(context.Background(), `
		UPDATE feed_history SET
			status = $1,
			total_products = $2,
			new_products = $3,
			updated_products = $4,
			deleted_products = $5,
			errors = $6,
			error_details = $7,
			completed_at = NOW()
		WHERE id = $8
	`, status, result.TotalItems, result.NewProducts, result.UpdatedProducts,
		result.DeletedProducts, result.Errors, []string{errorMsg}, historyID)
}

// GetVendorImportStats returns import statistics for vendor
func (v *VendorFeedImporter) GetVendorImportStats(vendorID uuid.UUID) map[string]interface{} {
	var totalFeeds, activeFeeds int
	var lastImportAt *time.Time
	var totalOffers int

	v.pool.QueryRow(context.Background(), `
		SELECT COUNT(*), COUNT(*) FILTER (WHERE is_active = true) FROM feeds WHERE vendor_id = $1
	`, vendorID).Scan(&totalFeeds, &activeFeeds)

	v.pool.QueryRow(context.Background(), `
		SELECT MAX(last_run_at) FROM feeds WHERE vendor_id = $1
	`, vendorID).Scan(&lastImportAt)

	v.pool.QueryRow(context.Background(), `
		SELECT COUNT(*) FROM offers WHERE vendor_id = $1
	`, vendorID).Scan(&totalOffers)

	return map[string]interface{}{
		"total_feeds":    totalFeeds,
		"active_feeds":   activeFeeds,
		"last_import_at": lastImportAt,
		"total_offers":   totalOffers,
	}
}
