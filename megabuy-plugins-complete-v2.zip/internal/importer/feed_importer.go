package importer

import (
	"context"
	"crypto/md5"
	"encoding/csv"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog/log"
)

type FeedImporter struct {
	pool *pgxpool.Pool
	ctx  context.Context
}

func NewFeedImporter(pool *pgxpool.Pool) *FeedImporter {
	return &FeedImporter{pool: pool, ctx: context.Background()}
}

type Feed struct {
	ID                uuid.UUID         `json:"id"`
	VendorID          uuid.UUID         `json:"vendor_id"`
	Name              string            `json:"name"`
	URL               string            `json:"url"`
	Type              string            `json:"type"`
	XMLItemPath       string            `json:"xml_item_path"`
	FieldMapping      map[string]string `json:"field_mapping"`
	DeactivateMissing bool              `json:"deactivate_missing"`
	IsActive          bool              `json:"is_active"`
}

type FeedItem struct {
	ExternalID    string
	Title         string
	Description   string
	Price         float64
	URL           string
	ImageURL      string
	EAN           string
	SKU           string
	Category      string
	Brand         string
	InStock       bool
	StockCount    int
	DeliveryDays  int
	DeliveryPrice float64
	Params        map[string]string
}

type ImportResult struct {
	FeedID          uuid.UUID `json:"feed_id"`
	HistoryID       uuid.UUID `json:"history_id"`
	Status          string    `json:"status"`
	TotalItems      int       `json:"total_items"`
	NewProducts     int       `json:"new_products"`
	UpdatedProducts int       `json:"updated_products"`
	DeletedProducts int       `json:"deleted_products"`
	Errors          int       `json:"errors"`
	ErrorDetails    []string  `json:"error_details"`
	StartedAt       time.Time `json:"started_at"`
	CompletedAt     time.Time `json:"completed_at"`
}

type PreviewResult struct {
	Items            []map[string]interface{} `json:"items"`
	DetectedFields   []string                 `json:"detected_fields"`
	SuggestedMapping []FieldMapping           `json:"suggested_mapping"`
	FeedType         string                   `json:"feed_type"`
	Error            string                   `json:"error,omitempty"`
}

type FieldMapping struct {
	SourceField string `json:"source_field"`
	TargetField string `json:"target_field"`
}

func (fi *FeedImporter) RunImport(feedID uuid.UUID) (*ImportResult, error) {
	feed, err := fi.getFeed(feedID)
	if err != nil {
		return nil, err
	}

	result := &ImportResult{FeedID: feedID, Status: "running", StartedAt: time.Now()}
	historyID, _ := fi.createHistory(feedID)
	result.HistoryID = historyID

	items, err := fi.downloadAndParse(feed)
	if err != nil {
		result.Status = "failed"
		result.ErrorDetails = append(result.ErrorDetails, err.Error())
		fi.updateHistory(result)
		return result, err
	}

	result.TotalItems = len(items)

	for _, item := range items {
		isNew, err := fi.processItem(feed, item)
		if err != nil {
			result.Errors++
			continue
		}
		if isNew {
			result.NewProducts++
		} else {
			result.UpdatedProducts++
		}
	}

	if feed.DeactivateMissing {
		result.DeletedProducts = fi.deactivateMissing(feed.VendorID, feedID)
	}

	result.Status = "completed"
	result.CompletedAt = time.Now()
	fi.updateHistory(result)

	log.Info().Str("feed", feed.Name).Int("total", result.TotalItems).Int("new", result.NewProducts).Msg("Import completed")
	return result, nil
}

func (fi *FeedImporter) GetPreview(url, feedType string, limit int) *PreviewResult {
	result := &PreviewResult{}

	data, err := fi.downloadPartial(url, 100*1024)
	if err != nil {
		result.Error = err.Error()
		return result
	}

	if feedType == "" {
		feedType = fi.detectType(data)
	}
	result.FeedType = feedType

	switch feedType {
	case "csv":
		result.Items, result.DetectedFields = fi.parseCSVPreview(data, limit)
	case "json":
		result.Items, result.DetectedFields = fi.parseJSONPreview(data, limit)
	default:
		result.Items, result.DetectedFields = fi.parseXMLPreview(data, limit)
	}

	result.SuggestedMapping = fi.autoMap(result.DetectedFields)
	return result
}

func (fi *FeedImporter) downloadPartial(url string, maxBytes int) ([]byte, error) {
	client := &http.Client{Timeout: 30 * time.Second}
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("User-Agent", "MegaBuy/1.0")
	req.Header.Set("Range", fmt.Sprintf("bytes=0-%d", maxBytes-1))

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	return io.ReadAll(io.LimitReader(resp.Body, int64(maxBytes)))
}

func (fi *FeedImporter) downloadFull(url string) ([]byte, error) {
	client := &http.Client{Timeout: 5 * time.Minute}
	resp, err := client.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	return io.ReadAll(resp.Body)
}

func (fi *FeedImporter) detectType(data []byte) string {
	s := strings.TrimSpace(string(data[:minInt(500, len(data))]))
	if strings.HasPrefix(s, "<?xml") || strings.HasPrefix(s, "<") {
		return "xml"
	}
	if strings.HasPrefix(s, "{") || strings.HasPrefix(s, "[") {
		return "json"
	}
	return "csv"
}

func (fi *FeedImporter) parseXMLPreview(data []byte, limit int) ([]map[string]interface{}, []string) {
	var items []map[string]interface{}
	fields := make(map[string]bool)

	decoder := xml.NewDecoder(strings.NewReader(string(data)))
	var inItem bool
	var current map[string]interface{}
	var elem string

	for {
		token, err := decoder.Token()
		if err != nil {
			break
		}

		switch t := token.(type) {
		case xml.StartElement:
			name := strings.ToUpper(t.Name.Local)
			if name == "SHOPITEM" || name == "ITEM" || name == "PRODUCT" {
				inItem = true
				current = make(map[string]interface{})
			}
			if inItem {
				elem = t.Name.Local
			}
		case xml.CharData:
			if inItem && elem != "" {
				val := strings.TrimSpace(string(t))
				if val != "" {
					current[elem] = val
					fields[elem] = true
				}
			}
		case xml.EndElement:
			name := strings.ToUpper(t.Name.Local)
			if name == "SHOPITEM" || name == "ITEM" || name == "PRODUCT" {
				if len(current) > 0 {
					items = append(items, current)
				}
				inItem = false
				if len(items) >= limit {
					goto done
				}
			}
			elem = ""
		}
	}
done:
	var f []string
	for k := range fields {
		f = append(f, k)
	}
	return items, f
}

func (fi *FeedImporter) parseCSVPreview(data []byte, limit int) ([]map[string]interface{}, []string) {
	var items []map[string]interface{}

	reader := csv.NewReader(strings.NewReader(string(data)))
	reader.Comma = ';'
	reader.LazyQuotes = true

	header, err := reader.Read()
	if err != nil {
		return items, nil
	}

	for i := 0; i < limit; i++ {
		record, err := reader.Read()
		if err != nil {
			break
		}
		if len(record) != len(header) {
			continue
		}
		item := make(map[string]interface{})
		for j, val := range record {
			item[header[j]] = val
		}
		items = append(items, item)
	}
	return items, header
}

func (fi *FeedImporter) parseJSONPreview(data []byte, limit int) ([]map[string]interface{}, []string) {
	var items []map[string]interface{}
	fields := make(map[string]bool)

	var arr []map[string]interface{}
	json.Unmarshal(data, &arr)

	for i, item := range arr {
		if i >= limit {
			break
		}
		items = append(items, item)
		for k := range item {
			fields[k] = true
		}
	}

	var f []string
	for k := range fields {
		f = append(f, k)
	}
	return items, f
}

func (fi *FeedImporter) autoMap(fields []string) []FieldMapping {
	var mappings []FieldMapping
	patterns := map[string]string{
		"(?i)^(item_id|product_id|id|sku)$":      "external_id",
		"(?i)^(title|name|productname)$":         "title",
		"(?i)^(description|popis)$":              "description",
		"(?i)^(price|price_vat|cena)$":           "price",
		"(?i)^(url|link)$":                       "url",
		"(?i)^(imgurl|image|image_url)$":         "image_url",
		"(?i)^(ean|gtin|barcode)$":               "ean",
		"(?i)^(categorytext|category)$":          "category",
		"(?i)^(brand|manufacturer)$":             "brand",
	}

	for _, field := range fields {
		for pattern, target := range patterns {
			if matched, _ := regexp.MatchString(pattern, field); matched {
				mappings = append(mappings, FieldMapping{SourceField: field, TargetField: target})
				break
			}
		}
	}
	return mappings
}

func (fi *FeedImporter) downloadAndParse(feed *Feed) ([]FeedItem, error) {
	data, err := fi.downloadFull(feed.URL)
	if err != nil {
		return nil, err
	}

	switch feed.Type {
	case "csv":
		return fi.parseFullCSV(data, feed.FieldMapping)
	case "json":
		return fi.parseFullJSON(data, feed.FieldMapping)
	default:
		return fi.parseFullXML(data, feed.XMLItemPath, feed.FieldMapping)
	}
}

func (fi *FeedImporter) parseFullXML(data []byte, itemPath string, mapping map[string]string) ([]FeedItem, error) {
	var items []FeedItem
	if itemPath == "" {
		itemPath = "SHOPITEM"
	}

	decoder := xml.NewDecoder(strings.NewReader(string(data)))
	var inItem bool
	var current FeedItem
	var elem string
	var params map[string]string

	for {
		token, err := decoder.Token()
		if err != nil {
			break
		}

		switch t := token.(type) {
		case xml.StartElement:
			name := strings.ToUpper(t.Name.Local)
			if name == strings.ToUpper(itemPath) {
				inItem = true
				current = FeedItem{}
				params = make(map[string]string)
			}
			if inItem {
				elem = name
				if name == "PARAM" {
					for _, attr := range t.Attr {
						if strings.ToUpper(attr.Name.Local) == "NAME" {
							elem = "PARAM:" + attr.Value
						}
					}
				}
			}
		case xml.CharData:
			if inItem && elem != "" {
				val := strings.TrimSpace(string(t))
				if val != "" {
					fi.setField(&current, elem, val, params, mapping)
				}
			}
		case xml.EndElement:
			if strings.ToUpper(t.Name.Local) == strings.ToUpper(itemPath) {
				current.Params = params
				if current.Title != "" || current.ExternalID != "" {
					items = append(items, current)
				}
				inItem = false
			}
			elem = ""
		}
	}
	return items, nil
}

func (fi *FeedImporter) parseFullCSV(data []byte, mapping map[string]string) ([]FeedItem, error) {
	var items []FeedItem
	reader := csv.NewReader(strings.NewReader(string(data)))
	reader.Comma = ';'
	reader.LazyQuotes = true

	header, _ := reader.Read()
	for i := range header {
		header[i] = strings.ToUpper(strings.TrimSpace(header[i]))
	}

	for {
		record, err := reader.Read()
		if err != nil {
			break
		}
		if len(record) != len(header) {
			continue
		}
		item := FeedItem{Params: make(map[string]string)}
		for i, val := range record {
			fi.setField(&item, header[i], val, item.Params, mapping)
		}
		if item.Title != "" || item.ExternalID != "" {
			items = append(items, item)
		}
	}
	return items, nil
}

func (fi *FeedImporter) parseFullJSON(data []byte, mapping map[string]string) ([]FeedItem, error) {
	var items []FeedItem
	var arr []map[string]interface{}
	json.Unmarshal(data, &arr)

	for _, row := range arr {
		item := FeedItem{Params: make(map[string]string)}
		for k, v := range row {
			if s, ok := v.(string); ok {
				fi.setField(&item, strings.ToUpper(k), s, item.Params, mapping)
			} else if n, ok := v.(float64); ok {
				fi.setField(&item, strings.ToUpper(k), fmt.Sprintf("%.2f", n), item.Params, mapping)
			}
		}
		if item.Title != "" || item.ExternalID != "" {
			items = append(items, item)
		}
	}
	return items, nil
}

func (fi *FeedImporter) setField(item *FeedItem, elem, val string, params map[string]string, mapping map[string]string) {
	if strings.HasPrefix(elem, "PARAM:") {
		params[strings.TrimPrefix(elem, "PARAM:")] = val
		return
	}

	switch elem {
	case "ITEM_ID", "PRODUCT_ID", "ID", "EXTERNAL_ID":
		item.ExternalID = val
	case "PRODUCTNAME", "NAME", "TITLE":
		item.Title = val
	case "DESCRIPTION", "POPIS":
		item.Description = val
	case "PRICE_VAT", "PRICE", "CENA":
		item.Price = parsePrice(val)
	case "URL", "LINK":
		item.URL = val
	case "IMGURL", "IMAGE", "IMAGE_URL":
		item.ImageURL = val
	case "EAN", "GTIN", "BARCODE":
		item.EAN = val
	case "PRODUCTNO", "SKU":
		item.SKU = val
	case "CATEGORYTEXT", "CATEGORY":
		item.Category = val
	case "MANUFACTURER", "BRAND":
		item.Brand = val
	case "STOCK_QUANTITY", "STOCK":
		item.StockCount = parseInt(val)
		item.InStock = item.StockCount > 0
	case "DELIVERY_DATE", "DELIVERY":
		item.DeliveryDays = parseInt(val)
	case "DELIVERY_PRICE":
		item.DeliveryPrice = parsePrice(val)
	}
}

func (fi *FeedImporter) processItem(feed *Feed, item FeedItem) (bool, error) {
	checksum := fmt.Sprintf("%x", md5.Sum([]byte(fmt.Sprintf("%s|%.2f|%s", item.Title, item.Price, item.URL))))

	var offerID, productID uuid.UUID
	var existingChecksum string
	var isNew bool

	err := fi.pool.QueryRow(fi.ctx, `
		SELECT id, product_id, checksum FROM offers 
		WHERE vendor_id = $1 AND (external_id = $2 OR (ean IS NOT NULL AND ean = $3))
		LIMIT 1
	`, feed.VendorID, item.ExternalID, item.EAN).Scan(&offerID, &productID, &existingChecksum)

	if err != nil {
		productID = fi.findOrCreateProduct(item)
		isNew = true
	} else if existingChecksum == checksum {
		fi.pool.Exec(fi.ctx, `UPDATE offers SET last_sync_at = NOW() WHERE id = $1`, offerID)
		return false, nil
	}

	if isNew {
		offerID = uuid.New()
		_, err = fi.pool.Exec(fi.ctx, `
			INSERT INTO offers (id, product_id, vendor_id, feed_id, external_id, title, description,
				price, url, image_url, in_stock, stock_count, delivery_days, delivery_price,
				is_active, checksum, last_sync_at, created_at, updated_at)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, true, $15, NOW(), NOW(), NOW())
		`, offerID, productID, feed.VendorID, feed.ID, item.ExternalID, item.Title, item.Description,
			item.Price, item.URL, item.ImageURL, item.InStock, item.StockCount, item.DeliveryDays,
			item.DeliveryPrice, checksum)
	} else {
		_, err = fi.pool.Exec(fi.ctx, `
			UPDATE offers SET title=$1, description=$2, price=$3, url=$4, image_url=$5,
				in_stock=$6, stock_count=$7, delivery_days=$8, delivery_price=$9,
				is_active=true, checksum=$10, last_sync_at=NOW(), updated_at=NOW()
			WHERE id=$11
		`, item.Title, item.Description, item.Price, item.URL, item.ImageURL,
			item.InStock, item.StockCount, item.DeliveryDays, item.DeliveryPrice, checksum, offerID)
	}

	fi.updateProductPrices(productID)
	return isNew, err
}

func (fi *FeedImporter) findOrCreateProduct(item FeedItem) uuid.UUID {
	var productID uuid.UUID

	if item.EAN != "" {
		if err := fi.pool.QueryRow(fi.ctx, `SELECT id FROM products WHERE ean = $1`, item.EAN).Scan(&productID); err == nil {
			return productID
		}
	}

	productID = uuid.New()
	slug := generateSlug(item.Title)
	categoryID := fi.findOrCreateCategory(item.Category)

	fi.pool.Exec(fi.ctx, `
		INSERT INTO products (id, category_id, title, slug, description, ean, sku, image_url, price_min, price_max, is_active, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $9, true, NOW(), NOW())
		ON CONFLICT (slug) DO NOTHING
	`, productID, categoryID, item.Title, slug, item.Description, nullStr(item.EAN), nullStr(item.SKU), item.ImageURL, item.Price)

	return productID
}

func (fi *FeedImporter) findOrCreateCategory(path string) uuid.UUID {
	if path == "" {
		var catID uuid.UUID
		fi.pool.QueryRow(fi.ctx, `SELECT id FROM categories LIMIT 1`).Scan(&catID)
		return catID
	}

	parts := strings.Split(path, "|")
	if len(parts) == 1 {
		parts = strings.Split(path, " > ")
	}

	var parentID *uuid.UUID
	var catID uuid.UUID

	for _, part := range parts {
		name := strings.TrimSpace(part)
		if name == "" {
			continue
		}
		slug := generateSlug(name)

		if err := fi.pool.QueryRow(fi.ctx, `SELECT id FROM categories WHERE slug = $1`, slug).Scan(&catID); err != nil {
			catID = uuid.New()
			fi.pool.Exec(fi.ctx, `
				INSERT INTO categories (id, parent_id, name, slug, is_active, created_at, updated_at)
				VALUES ($1, $2, $3, $4, true, NOW(), NOW())
				ON CONFLICT (slug) DO NOTHING
			`, catID, parentID, name, slug)
		}
		parentID = &catID
	}
	return catID
}

func (fi *FeedImporter) updateProductPrices(productID uuid.UUID) {
	fi.pool.Exec(fi.ctx, `
		UPDATE products SET
			price_min = (SELECT MIN(price) FROM offers WHERE product_id = $1 AND is_active = true),
			price_max = (SELECT MAX(price) FROM offers WHERE product_id = $1 AND is_active = true),
			offer_count = (SELECT COUNT(*) FROM offers WHERE product_id = $1 AND is_active = true),
			updated_at = NOW()
		WHERE id = $1
	`, productID)
}

func (fi *FeedImporter) deactivateMissing(vendorID, feedID uuid.UUID) int {
	result, _ := fi.pool.Exec(fi.ctx, `
		UPDATE offers SET is_active = false WHERE vendor_id = $1 AND feed_id = $2 
		AND last_sync_at < NOW() - INTERVAL '1 hour'
	`, vendorID, feedID)
	return int(result.RowsAffected())
}

func (fi *FeedImporter) getFeed(feedID uuid.UUID) (*Feed, error) {
	feed := &Feed{}
	var fieldMapping []byte
	err := fi.pool.QueryRow(fi.ctx, `
		SELECT id, vendor_id, name, url, type, xml_item_path, field_mapping, deactivate_missing, is_active
		FROM feeds WHERE id = $1
	`, feedID).Scan(&feed.ID, &feed.VendorID, &feed.Name, &feed.URL, &feed.Type,
		&feed.XMLItemPath, &fieldMapping, &feed.DeactivateMissing, &feed.IsActive)
	if len(fieldMapping) > 0 {
		json.Unmarshal(fieldMapping, &feed.FieldMapping)
	}
	return feed, err
}

func (fi *FeedImporter) createHistory(feedID uuid.UUID) (uuid.UUID, error) {
	historyID := uuid.New()
	_, err := fi.pool.Exec(fi.ctx, `INSERT INTO feed_history (id, feed_id, status, started_at) VALUES ($1, $2, 'running', NOW())`, historyID, feedID)
	return historyID, err
}

func (fi *FeedImporter) updateHistory(result *ImportResult) {
	fi.pool.Exec(fi.ctx, `
		UPDATE feed_history SET status=$1, total_products=$2, new_products=$3, updated_products=$4,
			deleted_products=$5, errors=$6, completed_at=NOW()
		WHERE id=$7
	`, result.Status, result.TotalItems, result.NewProducts, result.UpdatedProducts,
		result.DeletedProducts, result.Errors, result.HistoryID)
}

func generateSlug(text string) string {
	slug := strings.ToLower(text)
	slug = regexp.MustCompile(`[^a-z0-9]+`).ReplaceAllString(slug, "-")
	slug = strings.Trim(slug, "-")
	if len(slug) > 200 {
		slug = slug[:200]
	}
	if slug == "" {
		slug = fmt.Sprintf("p-%d", time.Now().UnixNano())
	}
	return slug
}

func parsePrice(s string) float64 {
	s = regexp.MustCompile(`[^0-9.,]+`).ReplaceAllString(s, "")
	s = strings.Replace(s, ",", ".", -1)
	p, _ := strconv.ParseFloat(s, 64)
	return p
}

func parseInt(s string) int {
	s = regexp.MustCompile(`[^0-9]+`).ReplaceAllString(s, "")
	n, _ := strconv.Atoi(s)
	return n
}

func nullStr(s string) interface{} {
	if s == "" {
		return nil
	}
	return s
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}
