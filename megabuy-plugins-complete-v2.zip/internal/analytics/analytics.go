package analytics

import (
	"context"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// AnalyticsService provides smart analytics for vendors
type AnalyticsService struct {
	pool *pgxpool.Pool
}

func NewAnalyticsService(pool *pgxpool.Pool) *AnalyticsService {
	return &AnalyticsService{pool: pool}
}

// VendorAnalytics comprehensive analytics for vendor
type VendorAnalytics struct {
	// Overview
	TotalClicks     int     `json:"total_clicks"`
	TotalViews      int     `json:"total_views"`
	TotalRevenue    float64 `json:"total_revenue"`
	ConversionRate  float64 `json:"conversion_rate"`
	AvgCPC          float64 `json:"avg_cpc"`
	
	// Trends (compared to previous period)
	ClicksTrend     float64 `json:"clicks_trend"`     // percentage change
	ViewsTrend      float64 `json:"views_trend"`
	RevenueTrend    float64 `json:"revenue_trend"`
	
	// Performance
	BuyBoxWins      int     `json:"buy_box_wins"`
	BuyBoxRate      float64 `json:"buy_box_rate"`
	TopProducts     []ProductAnalytics `json:"top_products"`
	TopCategories   []CategoryAnalytics `json:"top_categories"`
	
	// Daily breakdown
	DailyStats      []DailyAnalytics `json:"daily_stats"`
	
	// Competitors (for PAID mode)
	CompetitorCount int     `json:"competitor_count"`
	AvgPriceDiff    float64 `json:"avg_price_diff"`
	
	Period          string  `json:"period"`
	GeneratedAt     time.Time `json:"generated_at"`
}

type ProductAnalytics struct {
	ProductID   uuid.UUID `json:"product_id"`
	Title       string    `json:"title"`
	ImageURL    string    `json:"image_url"`
	Price       float64   `json:"price"`
	Clicks      int       `json:"clicks"`
	Views       int       `json:"views"`
	Conversions int       `json:"conversions"`
	Revenue     float64   `json:"revenue"`
	Position    int       `json:"position"`
	Trend       float64   `json:"trend"`
}

type CategoryAnalytics struct {
	CategoryID   uuid.UUID `json:"category_id"`
	CategoryName string    `json:"category_name"`
	ProductCount int       `json:"product_count"`
	Clicks       int       `json:"clicks"`
	Revenue      float64   `json:"revenue"`
	AvgPosition  float64   `json:"avg_position"`
}

type DailyAnalytics struct {
	Date        string  `json:"date"`
	Clicks      int     `json:"clicks"`
	Views       int     `json:"views"`
	Conversions int     `json:"conversions"`
	Revenue     float64 `json:"revenue"`
	Cost        float64 `json:"cost"`
}

// Subscription represents analytics subscription
type Subscription struct {
	ID          uuid.UUID `json:"id"`
	VendorID    uuid.UUID `json:"vendor_id"`
	Plan        string    `json:"plan"` // basic, pro, enterprise
	Status      string    `json:"status"` // active, cancelled, expired
	Features    []string  `json:"features"`
	Price       float64   `json:"price"`
	BillingCycle string   `json:"billing_cycle"` // monthly, yearly
	StartDate   time.Time `json:"start_date"`
	EndDate     time.Time `json:"end_date"`
	CreatedAt   time.Time `json:"created_at"`
}

// SubscriptionPlans available plans
var SubscriptionPlans = map[string]map[string]interface{}{
	"basic": {
		"name":         "Basic",
		"price":        0,
		"features":     []string{"basic_stats", "7_day_history"},
		"history_days": 7,
	},
	"pro": {
		"name":         "Pro",
		"price":        19.99,
		"features":     []string{"advanced_stats", "30_day_history", "competitor_analysis", "export"},
		"history_days": 30,
	},
	"enterprise": {
		"name":         "Enterprise",
		"price":        49.99,
		"features":     []string{"all_stats", "90_day_history", "competitor_analysis", "export", "api_access", "priority_support"},
		"history_days": 90,
	},
}

// GetVendorAnalytics returns comprehensive analytics for vendor
func (s *AnalyticsService) GetVendorAnalytics(vendorID uuid.UUID, period string) (*VendorAnalytics, error) {
	ctx := context.Background()
	
	// Determine date range
	var days int
	switch period {
	case "7days":
		days = 7
	case "30days":
		days = 30
	case "90days":
		days = 90
	default:
		days = 30
	}

	analytics := &VendorAnalytics{
		Period:      period,
		GeneratedAt: time.Now(),
	}

	// Get totals for current period
	s.pool.QueryRow(ctx, `
		SELECT 
			COUNT(*) as clicks,
			COALESCE(SUM(cost), 0) as revenue
		FROM clicks
		WHERE vendor_id = $1 
		AND created_at > NOW() - $2::interval
	`, vendorID, days).Scan(&analytics.TotalClicks, &analytics.TotalRevenue)

	// Calculate average CPC
	if analytics.TotalClicks > 0 {
		analytics.AvgCPC = analytics.TotalRevenue / float64(analytics.TotalClicks)
	}

	// Get previous period for trends
	var prevClicks int
	var prevRevenue float64
	s.pool.QueryRow(ctx, `
		SELECT COUNT(*), COALESCE(SUM(cost), 0)
		FROM clicks
		WHERE vendor_id = $1 
		AND created_at > NOW() - ($2::int * 2)::text::interval
		AND created_at <= NOW() - $2::int::text::interval
	`, vendorID, days).Scan(&prevClicks, &prevRevenue)

	if prevClicks > 0 {
		analytics.ClicksTrend = (float64(analytics.TotalClicks) - float64(prevClicks)) / float64(prevClicks) * 100
	}
	if prevRevenue > 0 {
		analytics.RevenueTrend = (analytics.TotalRevenue - prevRevenue) / prevRevenue * 100
	}

	// Buy Box analysis
	s.pool.QueryRow(ctx, `
		SELECT COUNT(*) FROM offers o
		WHERE o.vendor_id = $1 
		AND o.is_active = true
		AND o.price = (SELECT MIN(o2.price) FROM offers o2 WHERE o2.product_id = o.product_id AND o2.is_active = true)
	`, vendorID).Scan(&analytics.BuyBoxWins)

	var totalActive int
	s.pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE vendor_id = $1 AND is_active = true`, vendorID).Scan(&totalActive)
	if totalActive > 0 {
		analytics.BuyBoxRate = float64(analytics.BuyBoxWins) / float64(totalActive) * 100
	}

	// Top products
	analytics.TopProducts = s.getTopProducts(ctx, vendorID, days)
	
	// Top categories
	analytics.TopCategories = s.getTopCategories(ctx, vendorID, days)
	
	// Daily stats
	analytics.DailyStats = s.getDailyStats(ctx, vendorID, days)

	// Competitor analysis
	s.pool.QueryRow(ctx, `
		SELECT COUNT(DISTINCT o2.vendor_id)
		FROM offers o
		JOIN offers o2 ON o.product_id = o2.product_id AND o2.vendor_id != $1
		WHERE o.vendor_id = $1 AND o.is_active = true
	`, vendorID).Scan(&analytics.CompetitorCount)

	return analytics, nil
}

func (s *AnalyticsService) getTopProducts(ctx context.Context, vendorID uuid.UUID, days int) []ProductAnalytics {
	rows, _ := s.pool.Query(ctx, `
		SELECT 
			p.id, p.title, p.image_url, o.price,
			COUNT(c.id) as clicks,
			COALESCE(SUM(c.cost), 0) as revenue
		FROM offers o
		JOIN products p ON o.product_id = p.id
		LEFT JOIN clicks c ON c.offer_id = o.id AND c.created_at > NOW() - $2::interval
		WHERE o.vendor_id = $1
		GROUP BY p.id, p.title, p.image_url, o.price
		ORDER BY clicks DESC
		LIMIT 10
	`, vendorID, fmt.Sprintf("%d days", days))
	defer rows.Close()

	var products []ProductAnalytics
	for rows.Next() {
		var p ProductAnalytics
		rows.Scan(&p.ProductID, &p.Title, &p.ImageURL, &p.Price, &p.Clicks, &p.Revenue)
		products = append(products, p)
	}
	return products
}

func (s *AnalyticsService) getTopCategories(ctx context.Context, vendorID uuid.UUID, days int) []CategoryAnalytics {
	rows, _ := s.pool.Query(ctx, `
		SELECT 
			c.id, c.name, 
			COUNT(DISTINCT o.id) as product_count,
			COUNT(cl.id) as clicks,
			COALESCE(SUM(cl.cost), 0) as revenue
		FROM offers o
		JOIN products p ON o.product_id = p.id
		LEFT JOIN categories c ON p.category_id = c.id
		LEFT JOIN clicks cl ON cl.offer_id = o.id AND cl.created_at > NOW() - $2::interval
		WHERE o.vendor_id = $1
		GROUP BY c.id, c.name
		ORDER BY clicks DESC
		LIMIT 10
	`, vendorID, fmt.Sprintf("%d days", days))
	defer rows.Close()

	var categories []CategoryAnalytics
	for rows.Next() {
		var c CategoryAnalytics
		rows.Scan(&c.CategoryID, &c.CategoryName, &c.ProductCount, &c.Clicks, &c.Revenue)
		categories = append(categories, c)
	}
	return categories
}

func (s *AnalyticsService) getDailyStats(ctx context.Context, vendorID uuid.UUID, days int) []DailyAnalytics {
	rows, _ := s.pool.Query(ctx, `
		SELECT 
			DATE(created_at) as date,
			COUNT(*) as clicks,
			COALESCE(SUM(cost), 0) as cost
		FROM clicks
		WHERE vendor_id = $1 AND created_at > NOW() - $2::interval
		GROUP BY DATE(created_at)
		ORDER BY date DESC
	`, vendorID, fmt.Sprintf("%d days", days))
	defer rows.Close()

	var daily []DailyAnalytics
	for rows.Next() {
		var d DailyAnalytics
		rows.Scan(&d.Date, &d.Clicks, &d.Cost)
		d.Revenue = d.Cost // In CPC model, cost = revenue
		daily = append(daily, d)
	}
	return daily
}

// GetSubscription returns vendor's analytics subscription
func (s *AnalyticsService) GetSubscription(vendorID uuid.UUID) (*Subscription, error) {
	var sub Subscription
	err := s.pool.QueryRow(context.Background(), `
		SELECT id, vendor_id, plan, status, price, billing_cycle, start_date, end_date, created_at
		FROM analytics_subscriptions
		WHERE vendor_id = $1 AND status = 'active'
		ORDER BY created_at DESC LIMIT 1
	`, vendorID).Scan(&sub.ID, &sub.VendorID, &sub.Plan, &sub.Status, &sub.Price, 
		&sub.BillingCycle, &sub.StartDate, &sub.EndDate, &sub.CreatedAt)
	
	if err != nil {
		// Return basic plan if no subscription
		return &Subscription{
			VendorID: vendorID,
			Plan:     "basic",
			Status:   "active",
			Features: SubscriptionPlans["basic"]["features"].([]string),
			Price:    0,
		}, nil
	}

	// Get features for plan
	if plan, ok := SubscriptionPlans[sub.Plan]; ok {
		sub.Features = plan["features"].([]string)
	}

	return &sub, nil
}

// CreateSubscription creates new subscription
func (s *AnalyticsService) CreateSubscription(vendorID uuid.UUID, plan, billingCycle string) (*Subscription, error) {
	planData, ok := SubscriptionPlans[plan]
	if !ok {
		return nil, fmt.Errorf("invalid plan: %s", plan)
	}

	sub := &Subscription{
		ID:           uuid.New(),
		VendorID:     vendorID,
		Plan:         plan,
		Status:       "active",
		Price:        planData["price"].(float64),
		BillingCycle: billingCycle,
		StartDate:    time.Now(),
		CreatedAt:    time.Now(),
	}

	if billingCycle == "yearly" {
		sub.EndDate = sub.StartDate.AddDate(1, 0, 0)
		sub.Price = sub.Price * 10 // 2 months free
	} else {
		sub.EndDate = sub.StartDate.AddDate(0, 1, 0)
	}

	_, err := s.pool.Exec(context.Background(), `
		INSERT INTO analytics_subscriptions (id, vendor_id, plan, status, price, billing_cycle, start_date, end_date, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
	`, sub.ID, sub.VendorID, sub.Plan, sub.Status, sub.Price, sub.BillingCycle, sub.StartDate, sub.EndDate, sub.CreatedAt)

	return sub, err
}

// CancelSubscription cancels subscription
func (s *AnalyticsService) CancelSubscription(subscriptionID uuid.UUID) error {
	_, err := s.pool.Exec(context.Background(), `
		UPDATE analytics_subscriptions SET status = 'cancelled' WHERE id = $1
	`, subscriptionID)
	return err
}


