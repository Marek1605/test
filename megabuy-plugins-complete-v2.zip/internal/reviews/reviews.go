package reviews

import (
	"context"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ReviewSystem handles product and vendor reviews
type ReviewSystem struct {
	pool *pgxpool.Pool
	ctx  context.Context
}

func NewReviewSystem(pool *pgxpool.Pool) *ReviewSystem {
	return &ReviewSystem{pool: pool, ctx: context.Background()}
}

// Review model
type Review struct {
	ID          uuid.UUID  `json:"id"`
	ProductID   *uuid.UUID `json:"product_id"`
	VendorID    *uuid.UUID `json:"vendor_id"`
	UserID      uuid.UUID  `json:"user_id"`
	UserName    string     `json:"user_name"`
	Rating      int        `json:"rating"` // 1-5
	Title       string     `json:"title"`
	Content     string     `json:"content"`
	Pros        []string   `json:"pros"`
	Cons        []string   `json:"cons"`
	IsVerified  bool       `json:"is_verified"` // verified purchase
	IsApproved  bool       `json:"is_approved"`
	HelpfulCount int       `json:"helpful_count"`
	ReplyContent string    `json:"reply_content"`
	ReplyAt     *time.Time `json:"reply_at"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   time.Time  `json:"updated_at"`
}

// ReviewStats aggregated stats
type ReviewStats struct {
	TotalReviews  int            `json:"total_reviews"`
	AverageRating float64        `json:"average_rating"`
	Distribution  map[int]int    `json:"distribution"` // 1-5 star counts
}

// CreateReview adds new review
func (rs *ReviewSystem) CreateReview(review *Review) error {
	review.ID = uuid.New()
	review.IsApproved = false // Requires moderation
	review.CreatedAt = time.Now()
	review.UpdatedAt = time.Now()

	_, err := rs.pool.Exec(rs.ctx, `
		INSERT INTO reviews (id, product_id, vendor_id, user_id, user_name, rating,
			title, content, pros, cons, is_verified, is_approved, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
	`, review.ID, review.ProductID, review.VendorID, review.UserID, review.UserName,
		review.Rating, review.Title, review.Content, review.Pros, review.Cons,
		review.IsVerified, review.IsApproved, review.CreatedAt, review.UpdatedAt)

	return err
}

// GetProductReviews returns reviews for product
func (rs *ReviewSystem) GetProductReviews(productID uuid.UUID, page, limit int, approvedOnly bool) ([]Review, int) {
	var reviews []Review
	var total int

	offset := (page - 1) * limit

	// Count
	countQuery := `SELECT COUNT(*) FROM reviews WHERE product_id = $1`
	if approvedOnly {
		countQuery += " AND is_approved = true"
	}
	rs.pool.QueryRow(rs.ctx, countQuery, productID).Scan(&total)

	// Data
	query := `
		SELECT id, product_id, vendor_id, user_id, user_name, rating, title, content,
			pros, cons, is_verified, is_approved, helpful_count, reply_content,
			reply_at, created_at, updated_at
		FROM reviews
		WHERE product_id = $1
	`
	if approvedOnly {
		query += " AND is_approved = true"
	}
	query += " ORDER BY created_at DESC LIMIT $2 OFFSET $3"

	rows, _ := rs.pool.Query(rs.ctx, query, productID, limit, offset)
	defer rows.Close()

	for rows.Next() {
		var r Review
		rows.Scan(&r.ID, &r.ProductID, &r.VendorID, &r.UserID, &r.UserName,
			&r.Rating, &r.Title, &r.Content, &r.Pros, &r.Cons, &r.IsVerified,
			&r.IsApproved, &r.HelpfulCount, &r.ReplyContent, &r.ReplyAt,
			&r.CreatedAt, &r.UpdatedAt)
		reviews = append(reviews, r)
	}

	return reviews, total
}

// GetVendorReviews returns reviews for vendor
func (rs *ReviewSystem) GetVendorReviews(vendorID uuid.UUID, page, limit int) ([]Review, int) {
	var reviews []Review
	var total int

	offset := (page - 1) * limit

	rs.pool.QueryRow(rs.ctx, `
		SELECT COUNT(*) FROM reviews WHERE vendor_id = $1 AND is_approved = true
	`, vendorID).Scan(&total)

	rows, _ := rs.pool.Query(rs.ctx, `
		SELECT id, product_id, vendor_id, user_id, user_name, rating, title, content,
			pros, cons, is_verified, is_approved, helpful_count, reply_content,
			reply_at, created_at, updated_at
		FROM reviews
		WHERE vendor_id = $1 AND is_approved = true
		ORDER BY created_at DESC
		LIMIT $2 OFFSET $3
	`, vendorID, limit, offset)
	defer rows.Close()

	for rows.Next() {
		var r Review
		rows.Scan(&r.ID, &r.ProductID, &r.VendorID, &r.UserID, &r.UserName,
			&r.Rating, &r.Title, &r.Content, &r.Pros, &r.Cons, &r.IsVerified,
			&r.IsApproved, &r.HelpfulCount, &r.ReplyContent, &r.ReplyAt,
			&r.CreatedAt, &r.UpdatedAt)
		reviews = append(reviews, r)
	}

	return reviews, total
}

// GetProductStats returns review statistics
func (rs *ReviewSystem) GetProductStats(productID uuid.UUID) *ReviewStats {
	stats := &ReviewStats{
		Distribution: make(map[int]int),
	}

	rs.pool.QueryRow(rs.ctx, `
		SELECT COUNT(*), COALESCE(AVG(rating), 0)
		FROM reviews
		WHERE product_id = $1 AND is_approved = true
	`, productID).Scan(&stats.TotalReviews, &stats.AverageRating)

	// Distribution
	rows, _ := rs.pool.Query(rs.ctx, `
		SELECT rating, COUNT(*)
		FROM reviews
		WHERE product_id = $1 AND is_approved = true
		GROUP BY rating
	`, productID)
	defer rows.Close()

	for rows.Next() {
		var rating, count int
		rows.Scan(&rating, &count)
		stats.Distribution[rating] = count
	}

	return stats
}

// ApproveReview approves review (admin)
func (rs *ReviewSystem) ApproveReview(reviewID uuid.UUID) error {
	_, err := rs.pool.Exec(rs.ctx, `
		UPDATE reviews SET is_approved = true, updated_at = NOW() WHERE id = $1
	`, reviewID)
	
	// Update product rating
	var productID uuid.UUID
	rs.pool.QueryRow(rs.ctx, `SELECT product_id FROM reviews WHERE id = $1`, reviewID).Scan(&productID)
	rs.updateProductRating(productID)

	return err
}

// RejectReview deletes review (admin)
func (rs *ReviewSystem) RejectReview(reviewID uuid.UUID) error {
	_, err := rs.pool.Exec(rs.ctx, `DELETE FROM reviews WHERE id = $1`, reviewID)
	return err
}

// AddReply adds vendor reply to review
func (rs *ReviewSystem) AddReply(reviewID uuid.UUID, reply string) error {
	_, err := rs.pool.Exec(rs.ctx, `
		UPDATE reviews SET reply_content = $1, reply_at = NOW(), updated_at = NOW()
		WHERE id = $2
	`, reply, reviewID)
	return err
}

// MarkHelpful increases helpful count
func (rs *ReviewSystem) MarkHelpful(reviewID uuid.UUID) error {
	_, err := rs.pool.Exec(rs.ctx, `
		UPDATE reviews SET helpful_count = helpful_count + 1 WHERE id = $1
	`, reviewID)
	return err
}

// updateProductRating recalculates product rating
func (rs *ReviewSystem) updateProductRating(productID uuid.UUID) {
	var avgRating float64
	var reviewCount int

	rs.pool.QueryRow(rs.ctx, `
		SELECT COALESCE(AVG(rating), 0), COUNT(*)
		FROM reviews
		WHERE product_id = $1 AND is_approved = true
	`, productID).Scan(&avgRating, &reviewCount)

	rs.pool.Exec(rs.ctx, `
		UPDATE products SET rating = $1, review_count = $2, updated_at = NOW()
		WHERE id = $3
	`, avgRating, reviewCount, productID)
}

// GetPendingReviews returns reviews awaiting moderation (admin)
func (rs *ReviewSystem) GetPendingReviews(limit int) ([]Review, error) {
	var reviews []Review

	rows, err := rs.pool.Query(rs.ctx, `
		SELECT r.id, r.product_id, r.vendor_id, r.user_id, r.user_name, r.rating,
			r.title, r.content, r.pros, r.cons, r.is_verified, r.is_approved,
			r.helpful_count, r.reply_content, r.reply_at, r.created_at, r.updated_at
		FROM reviews r
		WHERE r.is_approved = false
		ORDER BY r.created_at ASC
		LIMIT $1
	`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var r Review
		rows.Scan(&r.ID, &r.ProductID, &r.VendorID, &r.UserID, &r.UserName,
			&r.Rating, &r.Title, &r.Content, &r.Pros, &r.Cons, &r.IsVerified,
			&r.IsApproved, &r.HelpfulCount, &r.ReplyContent, &r.ReplyAt,
			&r.CreatedAt, &r.UpdatedAt)
		reviews = append(reviews, r)
	}

	return reviews, nil
}
