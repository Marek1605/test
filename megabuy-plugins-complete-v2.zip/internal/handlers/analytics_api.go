package handlers

import (
	"megabuy/internal/analytics"
	"megabuy/internal/importer"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// AnalyticsAPIHandler handles analytics API
type AnalyticsAPIHandler struct {
	pool           *pgxpool.Pool
	analytics      *analytics.AnalyticsService
	vendorImporter *importer.VendorFeedImporter
}

func NewAnalyticsAPIHandler(pool *pgxpool.Pool) *AnalyticsAPIHandler {
	return &AnalyticsAPIHandler{
		pool:           pool,
		analytics:      analytics.NewAnalyticsService(pool),
		vendorImporter: importer.NewVendorFeedImporter(pool),
	}
}

// GetVendorAnalytics returns comprehensive analytics
func (h *AnalyticsAPIHandler) GetVendorAnalytics(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	period := c.Query("period", "30days")

	analytics, err := h.analytics.GetVendorAnalytics(vendorID, period)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get analytics"})
	}

	return c.JSON(analytics)
}

// GetSubscription returns vendor's analytics subscription
func (h *AnalyticsAPIHandler) GetSubscription(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	sub, err := h.analytics.GetSubscription(vendorID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get subscription"})
	}

	return c.JSON(sub)
}

// CreateSubscription creates new subscription
func (h *AnalyticsAPIHandler) CreateSubscription(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	type SubscriptionRequest struct {
		Plan         string `json:"plan"`
		BillingCycle string `json:"billing_cycle"`
	}

	var req SubscriptionRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	sub, err := h.analytics.CreateSubscription(vendorID, req.Plan, req.BillingCycle)
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": err.Error()})
	}

	return c.Status(201).JSON(sub)
}

// CancelSubscription cancels subscription
func (h *AnalyticsAPIHandler) CancelSubscription(c *fiber.Ctx) error {
	subscriptionID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid subscription ID"})
	}

	if err := h.analytics.CancelSubscription(subscriptionID); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to cancel subscription"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// GetSubscriptionPlans returns available plans
func (h *AnalyticsAPIHandler) GetSubscriptionPlans(c *fiber.Ctx) error {
	return c.JSON(analytics.SubscriptionPlans)
}

// === VENDOR FEED IMPORT ===

// RunVendorImport runs vendor-specific feed import
func (h *AnalyticsAPIHandler) RunVendorImport(c *fiber.Ctx) error {
	feedID, err := uuid.Parse(c.Params("feedId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid feed ID"})
	}

	// Run async
	go func() {
		h.vendorImporter.RunVendorImport(feedID)
	}()

	return c.JSON(fiber.Map{
		"status":  "started",
		"feed_id": feedID,
		"message": "Vendor import started in background",
	})
}

// RunVendorImportSync runs vendor import synchronously
func (h *AnalyticsAPIHandler) RunVendorImportSync(c *fiber.Ctx) error {
	feedID, err := uuid.Parse(c.Params("feedId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid feed ID"})
	}

	result, err := h.vendorImporter.RunVendorImport(feedID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(result)
}

// GetVendorImportStats returns import statistics
func (h *AnalyticsAPIHandler) GetVendorImportStats(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	stats := h.vendorImporter.GetVendorImportStats(vendorID)
	return c.JSON(stats)
}
