package handlers

import (
	"sort"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// OffersHandler handles product offers display
type OffersHandler struct {
	pool *pgxpool.Pool
}

func NewOffersHandler(pool *pgxpool.Pool) *OffersHandler {
	return &OffersHandler{pool: pool}
}

// Offer for display
type Offer struct {
	ID            uuid.UUID `json:"id"`
	ProductID     uuid.UUID `json:"product_id"`
	VendorID      uuid.UUID `json:"vendor_id"`
	VendorName    string    `json:"vendor_name"`
	VendorSlug    string    `json:"vendor_slug"`
	VendorLogo    string    `json:"vendor_logo"`
	VendorRating  float64   `json:"vendor_rating"`
	VendorReviews int       `json:"vendor_reviews"`
	Price         float64   `json:"price"`
	OriginalPrice float64   `json:"original_price"`
	URL           string    `json:"url"`
	InStock       bool      `json:"in_stock"`
	StockCount    int       `json:"stock_count"`
	DeliveryDays  int       `json:"delivery_days"`
	DeliveryPrice float64   `json:"delivery_price"`
	IsMegabuy     bool      `json:"is_megabuy"`
	CanAddToCart  bool      `json:"can_add_to_cart"`
	DisplayMode   string    `json:"display_mode"`
	Position      int       `json:"position"`
}

// OffersResponse for API
type OffersResponse struct {
	ProductID   uuid.UUID `json:"product_id"`
	ProductName string    `json:"product_name"`
	LowestPrice float64   `json:"lowest_price"`
	OfferCount  int       `json:"offer_count"`
	Offers      []Offer   `json:"offers"`
}

// GetProductOffers returns all offers for a product
func (h *OffersHandler) GetProductOffers(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	// Get product info
	var productName string
	h.pool.QueryRow(c.Context(), `SELECT title FROM products WHERE id = $1`, productID).Scan(&productName)

	// Get offers with vendor info
	rows, err := h.pool.Query(c.Context(), `
		SELECT 
			o.id, o.product_id, o.vendor_id, o.price, o.original_price, o.url,
			o.in_stock, o.stock_count, o.delivery_days, o.delivery_price,
			v.name as vendor_name, v.slug as vendor_slug, v.logo_url,
			v.rating, v.review_count, v.is_megabuy, v.display_mode
		FROM offers o
		JOIN vendors v ON o.vendor_id = v.id
		WHERE o.product_id = $1 AND o.is_active = true AND v.status = 'ACTIVE'
		ORDER BY 
			CASE WHEN v.display_mode = 'PREMIUM' THEN 0
				 WHEN v.display_mode = 'CPC' AND v.credit_balance > 0 THEN 1
				 ELSE 2 END,
			o.price ASC
	`, productID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Database error"})
	}
	defer rows.Close()

	var offers []Offer
	var lowestPrice float64 = 999999
	position := 1

	for rows.Next() {
		var o Offer
		var isMegabuy bool
		var displayMode string

		err := rows.Scan(
			&o.ID, &o.ProductID, &o.VendorID, &o.Price, &o.OriginalPrice, &o.URL,
			&o.InStock, &o.StockCount, &o.DeliveryDays, &o.DeliveryPrice,
			&o.VendorName, &o.VendorSlug, &o.VendorLogo,
			&o.VendorRating, &o.VendorReviews, &isMegabuy, &displayMode,
		)
		if err != nil {
			continue
		}

		o.IsMegabuy = isMegabuy
		o.DisplayMode = displayMode
		o.CanAddToCart = isMegabuy && o.InStock && o.StockCount > 0
		o.Position = position
		position++

		if o.Price < lowestPrice {
			lowestPrice = o.Price
		}

		offers = append(offers, o)
	}

	if lowestPrice == 999999 {
		lowestPrice = 0
	}

	return c.JSON(OffersResponse{
		ProductID:   productID,
		ProductName: productName,
		LowestPrice: lowestPrice,
		OfferCount:  len(offers),
		Offers:      offers,
	})
}

// GetBestOffer returns the best offer for a product (for buy button)
func (h *OffersHandler) GetBestOffer(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	// Get best offer (prefer MegaBuy in stock, then cheapest)
	var o Offer
	var isMegabuy bool

	err = h.pool.QueryRow(c.Context(), `
		SELECT 
			o.id, o.product_id, o.vendor_id, o.price, o.original_price, o.url,
			o.in_stock, o.stock_count, o.delivery_days, o.delivery_price,
			v.name, v.slug, v.logo_url, v.rating, v.review_count, v.is_megabuy
		FROM offers o
		JOIN vendors v ON o.vendor_id = v.id
		WHERE o.product_id = $1 AND o.is_active = true AND v.status = 'ACTIVE'
		ORDER BY 
			CASE WHEN v.is_megabuy AND o.in_stock THEN 0 ELSE 1 END,
			o.price ASC
		LIMIT 1
	`, productID).Scan(
		&o.ID, &o.ProductID, &o.VendorID, &o.Price, &o.OriginalPrice, &o.URL,
		&o.InStock, &o.StockCount, &o.DeliveryDays, &o.DeliveryPrice,
		&o.VendorName, &o.VendorSlug, &o.VendorLogo, &o.VendorRating, &o.VendorReviews, &isMegabuy,
	)

	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": "No offers found"})
	}

	o.IsMegabuy = isMegabuy
	o.CanAddToCart = isMegabuy && o.InStock && o.StockCount > 0
	o.Position = 1

	// Get total offer count
	var offerCount int
	h.pool.QueryRow(c.Context(), `
		SELECT COUNT(*) FROM offers o
		JOIN vendors v ON o.vendor_id = v.id
		WHERE o.product_id = $1 AND o.is_active = true AND v.status = 'ACTIVE'
	`, productID).Scan(&offerCount)

	return c.JSON(fiber.Map{
		"best_offer":   o,
		"offer_count":  offerCount,
		"free_shipping": o.Price >= 49 || o.DeliveryPrice == 0,
	})
}

// CompareOffers compares multiple products
func (h *OffersHandler) CompareOffers(c *fiber.Ctx) error {
	type CompareRequest struct {
		ProductIDs []string `json:"product_ids"`
	}

	var req CompareRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if len(req.ProductIDs) < 2 || len(req.ProductIDs) > 5 {
		return c.Status(400).JSON(fiber.Map{"error": "Compare 2-5 products"})
	}

	type ProductComparison struct {
		ProductID   uuid.UUID `json:"product_id"`
		Title       string    `json:"title"`
		ImageURL    string    `json:"image_url"`
		PriceMin    float64   `json:"price_min"`
		PriceMax    float64   `json:"price_max"`
		OfferCount  int       `json:"offer_count"`
		Rating      float64   `json:"rating"`
		ReviewCount int       `json:"review_count"`
	}

	var comparisons []ProductComparison

	for _, pidStr := range req.ProductIDs {
		pid, err := uuid.Parse(pidStr)
		if err != nil {
			continue
		}

		var p ProductComparison
		err = h.pool.QueryRow(c.Context(), `
			SELECT id, title, image_url, price_min, price_max, offer_count, rating, review_count
			FROM products WHERE id = $1
		`, pid).Scan(&p.ProductID, &p.Title, &p.ImageURL, &p.PriceMin, &p.PriceMax, &p.OfferCount, &p.Rating, &p.ReviewCount)

		if err == nil {
			comparisons = append(comparisons, p)
		}
	}

	// Sort by price
	sort.Slice(comparisons, func(i, j int) bool {
		return comparisons[i].PriceMin < comparisons[j].PriceMin
	})

	return c.JSON(fiber.Map{
		"products": comparisons,
		"cheapest": comparisons[0].ProductID,
	})
}

// TrackOfferClick tracks click and redirects
func (h *OffersHandler) TrackOfferClick(c *fiber.Ctx) error {
	offerID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid offer ID"})
	}

	// Get offer URL
	var url string
	var vendorID uuid.UUID
	var productID uuid.UUID

	err = h.pool.QueryRow(c.Context(), `
		SELECT url, vendor_id, product_id FROM offers WHERE id = $1
	`, offerID).Scan(&url, &vendorID, &productID)

	if err != nil || url == "" {
		return c.Status(404).JSON(fiber.Map{"error": "Offer not found"})
	}

	// Record click (async would be better in production)
	go func() {
		h.pool.Exec(c.Context(), `
			INSERT INTO clicks (id, offer_id, product_id, vendor_id, ip_hash, user_agent, created_at)
			VALUES ($1, $2, $3, $4, $5, $6, NOW())
		`, uuid.New(), offerID, productID, vendorID, hashIP(c.IP()), c.Get("User-Agent"))

		h.pool.Exec(c.Context(), `UPDATE offers SET click_count = click_count + 1 WHERE id = $1`, offerID)
	}()

	return c.Redirect(url, 302)
}

// Helper for IP hashing
func hashIP(ip string) string {
	// Simple hash for privacy
	return ip[:min(len(ip), 8)] + "***"
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
