package handlers

import (
	"megabuy/internal/importer"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// FeedAPIHandler handles feed import API
type FeedAPIHandler struct {
	pool     *pgxpool.Pool
	importer *importer.FeedImporter
}

func NewFeedAPIHandler(pool *pgxpool.Pool) *FeedAPIHandler {
	return &FeedAPIHandler{
		pool:     pool,
		importer: importer.NewFeedImporter(pool),
	}
}

// PreviewFeed returns feed preview with auto-detection
func (h *FeedAPIHandler) PreviewFeed(c *fiber.Ctx) error {
	type PreviewRequest struct {
		URL      string `json:"url"`
		FeedType string `json:"feed_type"`
		Limit    int    `json:"limit"`
	}

	var req PreviewRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if req.URL == "" {
		return c.Status(400).JSON(fiber.Map{"error": "URL is required"})
	}

	if req.Limit == 0 || req.Limit > 10 {
		req.Limit = 5
	}

	result := h.importer.GetPreview(req.URL, req.FeedType, req.Limit)

	if result.Error != "" {
		return c.Status(400).JSON(fiber.Map{"error": result.Error})
	}

	return c.JSON(result)
}

// RunImport starts feed import
func (h *FeedAPIHandler) RunImport(c *fiber.Ctx) error {
	feedID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid feed ID"})
	}

	// Run in background
	go func() {
		h.importer.RunImport(feedID)
	}()

	return c.JSON(fiber.Map{
		"status":  "started",
		"feed_id": feedID,
		"message": "Import started in background",
	})
}

// RunImportSync runs import synchronously (for testing)
func (h *FeedAPIHandler) RunImportSync(c *fiber.Ctx) error {
	feedID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid feed ID"})
	}

	result, err := h.importer.RunImport(feedID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(result)
}

// GetImportHistory returns import history for feed
func (h *FeedAPIHandler) GetImportHistory(c *fiber.Ctx) error {
	feedID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid feed ID"})
	}

	type HistoryEntry struct {
		ID              uuid.UUID `json:"id"`
		Status          string    `json:"status"`
		TotalProducts   int       `json:"total_products"`
		NewProducts     int       `json:"new_products"`
		UpdatedProducts int       `json:"updated_products"`
		DeletedProducts int       `json:"deleted_products"`
		Errors          int       `json:"errors"`
		StartedAt       string    `json:"started_at"`
		CompletedAt     *string   `json:"completed_at"`
	}

	rows, err := h.pool.Query(c.Context(), `
		SELECT id, status, total_products, new_products, updated_products, 
			deleted_products, errors, started_at, completed_at
		FROM feed_history
		WHERE feed_id = $1
		ORDER BY started_at DESC
		LIMIT 20
	`, feedID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Database error"})
	}
	defer rows.Close()

	var history []HistoryEntry
	for rows.Next() {
		var h HistoryEntry
		rows.Scan(&h.ID, &h.Status, &h.TotalProducts, &h.NewProducts, &h.UpdatedProducts,
			&h.DeletedProducts, &h.Errors, &h.StartedAt, &h.CompletedAt)
		history = append(history, h)
	}

	return c.JSON(history)
}

// GetFeed returns feed details
func (h *FeedAPIHandler) GetFeed(c *fiber.Ctx) error {
	feedID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid feed ID"})
	}

	type Feed struct {
		ID                uuid.UUID `json:"id"`
		VendorID          uuid.UUID `json:"vendor_id"`
		Name              string    `json:"name"`
		URL               string    `json:"url"`
		Type              string    `json:"type"`
		XMLItemPath       string    `json:"xml_item_path"`
		DeactivateMissing bool      `json:"deactivate_missing"`
		IsActive          bool      `json:"is_active"`
		LastRunAt         *string   `json:"last_run_at"`
		LastStatus        string    `json:"last_status"`
		OfferCount        int       `json:"offer_count"`
	}

	var f Feed
	err = h.pool.QueryRow(c.Context(), `
		SELECT f.id, f.vendor_id, f.name, f.url, f.type, f.xml_item_path,
			f.deactivate_missing, f.is_active, f.last_run_at, f.last_status,
			(SELECT COUNT(*) FROM offers WHERE feed_id = f.id) as offer_count
		FROM feeds f
		WHERE f.id = $1
	`, feedID).Scan(&f.ID, &f.VendorID, &f.Name, &f.URL, &f.Type, &f.XMLItemPath,
		&f.DeactivateMissing, &f.IsActive, &f.LastRunAt, &f.LastStatus, &f.OfferCount)

	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": "Feed not found"})
	}

	return c.JSON(f)
}

// CreateFeed creates new feed
func (h *FeedAPIHandler) CreateFeed(c *fiber.Ctx) error {
	type CreateFeedRequest struct {
		VendorID          uuid.UUID         `json:"vendor_id"`
		Name              string            `json:"name"`
		URL               string            `json:"url"`
		Type              string            `json:"type"`
		XMLItemPath       string            `json:"xml_item_path"`
		FieldMapping      map[string]string `json:"field_mapping"`
		DeactivateMissing bool              `json:"deactivate_missing"`
	}

	var req CreateFeedRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if req.Name == "" || req.URL == "" {
		return c.Status(400).JSON(fiber.Map{"error": "Name and URL are required"})
	}

	if req.Type == "" {
		req.Type = "xml"
	}

	feedID := uuid.New()
	_, err := h.pool.Exec(c.Context(), `
		INSERT INTO feeds (id, vendor_id, name, url, type, xml_item_path, field_mapping,
			deactivate_missing, is_active, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, NOW(), NOW())
	`, feedID, req.VendorID, req.Name, req.URL, req.Type, req.XMLItemPath,
		req.FieldMapping, req.DeactivateMissing)

	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to create feed"})
	}

	return c.Status(201).JSON(fiber.Map{
		"id":      feedID,
		"message": "Feed created successfully",
	})
}

// UpdateFeed updates feed
func (h *FeedAPIHandler) UpdateFeed(c *fiber.Ctx) error {
	feedID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid feed ID"})
	}

	type UpdateFeedRequest struct {
		Name              string            `json:"name"`
		URL               string            `json:"url"`
		Type              string            `json:"type"`
		XMLItemPath       string            `json:"xml_item_path"`
		FieldMapping      map[string]string `json:"field_mapping"`
		DeactivateMissing bool              `json:"deactivate_missing"`
		IsActive          bool              `json:"is_active"`
	}

	var req UpdateFeedRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	_, err = h.pool.Exec(c.Context(), `
		UPDATE feeds SET
			name = $1, url = $2, type = $3, xml_item_path = $4, field_mapping = $5,
			deactivate_missing = $6, is_active = $7, updated_at = NOW()
		WHERE id = $8
	`, req.Name, req.URL, req.Type, req.XMLItemPath, req.FieldMapping,
		req.DeactivateMissing, req.IsActive, feedID)

	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to update feed"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// DeleteFeed deletes feed
func (h *FeedAPIHandler) DeleteFeed(c *fiber.Ctx) error {
	feedID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid feed ID"})
	}

	_, err = h.pool.Exec(c.Context(), `DELETE FROM feeds WHERE id = $1`, feedID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to delete feed"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// ListFeeds lists all feeds (admin)
func (h *FeedAPIHandler) ListFeeds(c *fiber.Ctx) error {
	vendorID := c.Query("vendor_id")
	
	query := `
		SELECT f.id, f.vendor_id, v.name as vendor_name, f.name, f.url, f.type,
			f.is_active, f.last_run_at, f.last_status,
			(SELECT COUNT(*) FROM offers WHERE feed_id = f.id) as offer_count
		FROM feeds f
		LEFT JOIN vendors v ON f.vendor_id = v.id
	`
	
	var args []interface{}
	if vendorID != "" {
		vid, err := uuid.Parse(vendorID)
		if err == nil {
			query += " WHERE f.vendor_id = $1"
			args = append(args, vid)
		}
	}
	
	query += " ORDER BY f.created_at DESC"

	rows, err := h.pool.Query(c.Context(), query, args...)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Database error"})
	}
	defer rows.Close()

	type FeedItem struct {
		ID         uuid.UUID `json:"id"`
		VendorID   uuid.UUID `json:"vendor_id"`
		VendorName string    `json:"vendor_name"`
		Name       string    `json:"name"`
		URL        string    `json:"url"`
		Type       string    `json:"type"`
		IsActive   bool      `json:"is_active"`
		LastRunAt  *string   `json:"last_run_at"`
		LastStatus string    `json:"last_status"`
		OfferCount int       `json:"offer_count"`
	}

	var feeds []FeedItem
	for rows.Next() {
		var f FeedItem
		rows.Scan(&f.ID, &f.VendorID, &f.VendorName, &f.Name, &f.URL, &f.Type,
			&f.IsActive, &f.LastRunAt, &f.LastStatus, &f.OfferCount)
		feeds = append(feeds, f)
	}

	return c.JSON(feeds)
}
