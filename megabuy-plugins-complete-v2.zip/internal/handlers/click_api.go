package handlers

import (
	"megabuy/internal/tracking"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ClickAPIHandler handles click tracking API
type ClickAPIHandler struct {
	pool    *pgxpool.Pool
	tracker *tracking.ClickTracker
}

func NewClickAPIHandler(pool *pgxpool.Pool) *ClickAPIHandler {
	return &ClickAPIHandler{
		pool:    pool,
		tracker: tracking.NewClickTracker(pool),
	}
}

// TrackClick records a click
func (h *ClickAPIHandler) TrackClick(c *fiber.Ctx) error {
	offerID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid offer ID"})
	}

	var productID uuid.UUID
	var vendorID uuid.UUID
	
	// Get product and vendor from offer
	h.pool.QueryRow(c.Context(), `
		SELECT product_id, vendor_id FROM offers WHERE id = $1
	`, offerID).Scan(&productID, &vendorID)

	req := tracking.TrackClickRequest{
		OfferID:     offerID,
		ProductID:   productID,
		VendorID:    vendorID,
		IP:          c.IP(),
		UserAgent:   c.Get("User-Agent"),
		Referer:     c.Get("Referer"),
		ClickType:   c.Query("type", "affiliate"),
		UTMSource:   c.Query("utm_source"),
		UTMMedium:   c.Query("utm_medium"),
		UTMCampaign: c.Query("utm_campaign"),
	}

	result, err := h.tracker.TrackClick(req)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	// If redirect requested
	if c.Query("redirect") == "1" {
		return c.Redirect(result.RedirectURL, 302)
	}

	return c.JSON(result)
}

// GetClickStats returns click statistics (admin)
func (h *ClickAPIHandler) GetClickStats(c *fiber.Ctx) error {
	type StatsQuery struct {
		VendorID  string `query:"vendor_id"`
		ProductID string `query:"product_id"`
		DateFrom  string `query:"date_from"`
		DateTo    string `query:"date_to"`
	}

	var q StatsQuery
	c.QueryParser(&q)

	// Build query
	query := `
		SELECT 
			DATE(created_at) as date,
			COUNT(*) as clicks,
			COUNT(*) FILTER (WHERE is_charged = true) as charged_clicks,
			COALESCE(SUM(cost), 0) as total_cost
		FROM clicks
		WHERE created_at >= COALESCE($1::date, created_at::date - 30)
		AND created_at <= COALESCE($2::date, CURRENT_DATE)
	`

	args := []interface{}{nullIfEmpty(q.DateFrom), nullIfEmpty(q.DateTo)}

	if q.VendorID != "" {
		if vid, err := uuid.Parse(q.VendorID); err == nil {
			query += " AND vendor_id = $3"
			args = append(args, vid)
		}
	}

	if q.ProductID != "" {
		if pid, err := uuid.Parse(q.ProductID); err == nil {
			argNum := len(args) + 1
			query += " AND product_id = $" + string(rune('0'+argNum))
			args = append(args, pid)
		}
	}

	query += " GROUP BY DATE(created_at) ORDER BY date DESC LIMIT 30"

	rows, err := h.pool.Query(c.Context(), query, args...)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Database error"})
	}
	defer rows.Close()

	type DayStat struct {
		Date          string  `json:"date"`
		Clicks        int     `json:"clicks"`
		ChargedClicks int     `json:"charged_clicks"`
		TotalCost     float64 `json:"total_cost"`
	}

	var stats []DayStat
	for rows.Next() {
		var s DayStat
		rows.Scan(&s.Date, &s.Clicks, &s.ChargedClicks, &s.TotalCost)
		stats = append(stats, s)
	}

	// Get totals
	var totalClicks, totalCharged int
	var totalCost float64

	totalQuery := `
		SELECT COUNT(*), COUNT(*) FILTER (WHERE is_charged = true), COALESCE(SUM(cost), 0)
		FROM clicks
		WHERE created_at >= COALESCE($1::date, created_at::date - 30)
		AND created_at <= COALESCE($2::date, CURRENT_DATE)
	`
	h.pool.QueryRow(c.Context(), totalQuery, nullIfEmpty(q.DateFrom), nullIfEmpty(q.DateTo)).
		Scan(&totalClicks, &totalCharged, &totalCost)

	return c.JSON(fiber.Map{
		"daily":          stats,
		"total_clicks":   totalClicks,
		"charged_clicks": totalCharged,
		"total_cost":     totalCost,
	})
}

// GetRecentClicks returns recent clicks (admin)
func (h *ClickAPIHandler) GetRecentClicks(c *fiber.Ctx) error {
	limit := c.QueryInt("limit", 50)
	vendorID := c.Query("vendor_id")

	query := `
		SELECT c.id, c.offer_id, c.product_id, c.vendor_id, c.cost, c.is_charged,
			c.ip_hash, c.created_at,
			p.title as product_title, v.name as vendor_name
		FROM clicks c
		LEFT JOIN products p ON c.product_id = p.id
		LEFT JOIN vendors v ON c.vendor_id = v.id
	`

	var args []interface{}
	if vendorID != "" {
		if vid, err := uuid.Parse(vendorID); err == nil {
			query += " WHERE c.vendor_id = $1"
			args = append(args, vid)
		}
	}

	query += " ORDER BY c.created_at DESC LIMIT $" + string(rune('0'+len(args)+1))
	args = append(args, limit)

	rows, err := h.pool.Query(c.Context(), query, args...)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Database error"})
	}
	defer rows.Close()

	type Click struct {
		ID           uuid.UUID `json:"id"`
		OfferID      uuid.UUID `json:"offer_id"`
		ProductID    uuid.UUID `json:"product_id"`
		VendorID     uuid.UUID `json:"vendor_id"`
		Cost         float64   `json:"cost"`
		IsCharged    bool      `json:"is_charged"`
		IPHash       string    `json:"ip_hash"`
		CreatedAt    string    `json:"created_at"`
		ProductTitle string    `json:"product_title"`
		VendorName   string    `json:"vendor_name"`
	}

	var clicks []Click
	for rows.Next() {
		var cl Click
		rows.Scan(&cl.ID, &cl.OfferID, &cl.ProductID, &cl.VendorID, &cl.Cost,
			&cl.IsCharged, &cl.IPHash, &cl.CreatedAt, &cl.ProductTitle, &cl.VendorName)
		clicks = append(clicks, cl)
	}

	return c.JSON(clicks)
}

// GetTopProducts returns top clicked products
func (h *ClickAPIHandler) GetTopProducts(c *fiber.Ctx) error {
	period := c.Query("period", "30days")
	limit := c.QueryInt("limit", 10)

	var interval string
	switch period {
	case "7days":
		interval = "7 days"
	case "90days":
		interval = "90 days"
	default:
		interval = "30 days"
	}

	rows, err := h.pool.Query(c.Context(), `
		SELECT p.id, p.title, p.slug, p.image_url, COUNT(c.id) as clicks, 
			COALESCE(SUM(c.cost), 0) as cost
		FROM clicks c
		JOIN products p ON c.product_id = p.id
		WHERE c.created_at > NOW() - $1::interval
		GROUP BY p.id, p.title, p.slug, p.image_url
		ORDER BY clicks DESC
		LIMIT $2
	`, interval, limit)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Database error"})
	}
	defer rows.Close()

	type TopProduct struct {
		ID       uuid.UUID `json:"id"`
		Title    string    `json:"title"`
		Slug     string    `json:"slug"`
		ImageURL string    `json:"image_url"`
		Clicks   int       `json:"clicks"`
		Cost     float64   `json:"cost"`
	}

	var products []TopProduct
	for rows.Next() {
		var p TopProduct
		rows.Scan(&p.ID, &p.Title, &p.Slug, &p.ImageURL, &p.Clicks, &p.Cost)
		products = append(products, p)
	}

	return c.JSON(products)
}

// GetTopVendors returns top vendors by clicks
func (h *ClickAPIHandler) GetTopVendors(c *fiber.Ctx) error {
	period := c.Query("period", "30days")
	limit := c.QueryInt("limit", 10)

	var interval string
	switch period {
	case "7days":
		interval = "7 days"
	case "90days":
		interval = "90 days"
	default:
		interval = "30 days"
	}

	rows, err := h.pool.Query(c.Context(), `
		SELECT v.id, v.name, v.slug, v.logo_url, COUNT(c.id) as clicks, 
			COALESCE(SUM(c.cost), 0) as cost, v.credit_balance
		FROM clicks c
		JOIN vendors v ON c.vendor_id = v.id
		WHERE c.created_at > NOW() - $1::interval
		GROUP BY v.id, v.name, v.slug, v.logo_url, v.credit_balance
		ORDER BY clicks DESC
		LIMIT $2
	`, interval, limit)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Database error"})
	}
	defer rows.Close()

	type TopVendor struct {
		ID            uuid.UUID `json:"id"`
		Name          string    `json:"name"`
		Slug          string    `json:"slug"`
		LogoURL       string    `json:"logo_url"`
		Clicks        int       `json:"clicks"`
		Cost          float64   `json:"cost"`
		CreditBalance float64   `json:"credit_balance"`
	}

	var vendors []TopVendor
	for rows.Next() {
		var v TopVendor
		rows.Scan(&v.ID, &v.Name, &v.Slug, &v.LogoURL, &v.Clicks, &v.Cost, &v.CreditBalance)
		vendors = append(vendors, v)
	}

	return c.JSON(vendors)
}

func nullIfEmpty(s string) interface{} {
	if s == "" {
		return nil
	}
	return s
}
