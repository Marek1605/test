package handlers

import (
	"megabuy/internal/vendor"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ShopAPIHandler handles shop management API
type ShopAPIHandler struct {
	pool           *pgxpool.Pool
	shopManager    *vendor.ShopManager
	productManager *vendor.ProductManager
}

func NewShopAPIHandler(pool *pgxpool.Pool) *ShopAPIHandler {
	return &ShopAPIHandler{
		pool:           pool,
		shopManager:    vendor.NewShopManager(pool),
		productManager: vendor.NewProductManager(pool),
	}
}

// === SHOP MANAGEMENT ===

// GetShop returns shop details
func (h *ShopAPIHandler) GetShop(c *fiber.Ctx) error {
	shopID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid shop ID"})
	}

	shop, err := h.shopManager.GetShop(shopID)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": "Shop not found"})
	}

	return c.JSON(shop)
}

// GetMyShop returns current vendor's shop
func (h *ShopAPIHandler) GetMyShop(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	shop, err := h.shopManager.GetShopByVendor(vendorID)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": "Shop not found"})
	}

	return c.JSON(shop)
}

// CreateShop creates new shop (registration)
func (h *ShopAPIHandler) CreateShop(c *fiber.Ctx) error {
	var shop vendor.Shop
	if err := c.BodyParser(&shop); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if shop.ShopName == "" {
		return c.Status(400).JSON(fiber.Map{"error": "Shop name is required"})
	}

	if err := h.shopManager.CreateShop(&shop); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to create shop"})
	}

	return c.Status(201).JSON(fiber.Map{
		"success": true,
		"shop_id": shop.ID,
		"message": "Shop created and pending approval",
	})
}

// UpdateShop updates shop info
func (h *ShopAPIHandler) UpdateShop(c *fiber.Ctx) error {
	shopID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid shop ID"})
	}

	var shop vendor.Shop
	if err := c.BodyParser(&shop); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	shop.ID = shopID
	if err := h.shopManager.UpdateShop(&shop); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to update shop"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// UpdateShopStatus updates shop status (admin)
func (h *ShopAPIHandler) UpdateShopStatus(c *fiber.Ctx) error {
	shopID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid shop ID"})
	}

	type StatusRequest struct {
		Status string `json:"status"`
	}

	var req StatusRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if err := h.shopManager.UpdateShopStatus(shopID, req.Status); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(fiber.Map{"success": true, "status": req.Status})
}

// GetPendingShops returns shops awaiting approval (admin)
func (h *ShopAPIHandler) GetPendingShops(c *fiber.Ctx) error {
	limit := c.QueryInt("limit", 20)

	shops, err := h.shopManager.GetPendingShops(limit)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get pending shops"})
	}

	return c.JSON(shops)
}

// === VENDOR SETTINGS ===

// GetVendorSettings returns vendor settings
func (h *ShopAPIHandler) GetVendorSettings(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	settings, err := h.shopManager.GetVendorSettings(vendorID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get settings"})
	}

	return c.JSON(settings)
}

// SaveVendorSettings saves vendor settings
func (h *ShopAPIHandler) SaveVendorSettings(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	var settings map[string]string
	if err := c.BodyParser(&settings); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if err := h.shopManager.SaveVendorSettings(vendorID, settings); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to save settings"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// GetDisplayMode returns vendor display mode
func (h *ShopAPIHandler) GetDisplayMode(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	mode := h.shopManager.GetDisplayMode(vendorID)
	return c.JSON(mode)
}

// === VENDOR PRODUCTS ===

// GetVendorProducts returns vendor's products
func (h *ShopAPIHandler) GetVendorProducts(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	page := c.QueryInt("page", 1)
	limit := c.QueryInt("limit", 20)
	search := c.Query("search", "")
	status := c.Query("status", "all")

	products, total := h.productManager.GetVendorProducts(vendorID, page, limit, search, status)

	return c.JSON(fiber.Map{
		"products": products,
		"total":    total,
		"page":     page,
		"limit":    limit,
	})
}

// GetProductStats returns product statistics
func (h *ShopAPIHandler) GetProductStats(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	stats := h.productManager.GetProductStats(vendorID)
	return c.JSON(stats)
}

// GetCategoryStats returns category distribution
func (h *ShopAPIHandler) GetCategoryStats(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("vendorId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	stats := h.productManager.GetCategoryStats(vendorID)
	return c.JSON(stats)
}

// === APPROVALS (Admin) ===

// GetPendingApprovals returns pending product approvals
func (h *ShopAPIHandler) GetPendingApprovals(c *fiber.Ctx) error {
	limit := c.QueryInt("limit", 50)

	approvals, err := h.productManager.GetPendingApprovals(limit)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get approvals"})
	}

	return c.JSON(approvals)
}

// ApproveProduct approves pending approval
func (h *ShopAPIHandler) ApproveProduct(c *fiber.Ctx) error {
	approvalID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid approval ID"})
	}

	type ApprovalRequest struct {
		AdminID uuid.UUID `json:"admin_id"`
		Note    string    `json:"note"`
	}

	var req ApprovalRequest
	c.BodyParser(&req)

	if err := h.productManager.ApproveProduct(approvalID, req.AdminID, req.Note); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to approve"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// RejectProduct rejects pending approval
func (h *ShopAPIHandler) RejectProduct(c *fiber.Ctx) error {
	approvalID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid approval ID"})
	}

	type ApprovalRequest struct {
		AdminID uuid.UUID `json:"admin_id"`
		Note    string    `json:"note"`
	}

	var req ApprovalRequest
	c.BodyParser(&req)

	if err := h.productManager.RejectProduct(approvalID, req.AdminID, req.Note); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to reject"})
	}

	return c.JSON(fiber.Map{"success": true})
}
