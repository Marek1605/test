package handlers

import (
	"megabuy/internal/ai"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// AIAPIHandler handles AI content generation
type AIAPIHandler struct {
	pool      *pgxpool.Pool
	generator *ai.AIGenerator
}

func NewAIAPIHandler(pool *pgxpool.Pool, apiKey string) *AIAPIHandler {
	return &AIAPIHandler{
		pool:      pool,
		generator: ai.NewAIGenerator(pool, apiKey),
	}
}

// GenerateDescription generates product description
func (h *AIAPIHandler) GenerateDescription(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	style := c.Query("style", "professional")
	length := c.Query("length", "medium")

	result, err := h.generator.GenerateDescription(productID, style, length)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(result)
}

// ImproveDescription improves existing description
func (h *AIAPIHandler) ImproveDescription(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	type ImprovementRequest struct {
		Improvements []string `json:"improvements"` // seo, benefits, structure, cta
	}

	var req ImprovementRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	result, err := h.generator.ImproveDescription(productID, req.Improvements)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(fiber.Map{"description": result})
}

// GenerateFAQ generates FAQ for product
func (h *AIAPIHandler) GenerateFAQ(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	count := c.QueryInt("count", 5)

	result, err := h.generator.GenerateFAQ(productID, count)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(result)
}

// GenerateWhyBuy generates "why buy" reasons
func (h *AIAPIHandler) GenerateWhyBuy(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	result, err := h.generator.GenerateWhyBuy(productID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(result)
}

// FindAlternatives finds alternative products
func (h *AIAPIHandler) FindAlternatives(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	result, err := h.generator.FindAlternatives(productID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(result)
}

// CompareProducts compares multiple products
func (h *AIAPIHandler) CompareProducts(c *fiber.Ctx) error {
	type CompareRequest struct {
		ProductIDs []string `json:"product_ids"`
	}

	var req CompareRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if len(req.ProductIDs) < 2 {
		return c.Status(400).JSON(fiber.Map{"error": "Need at least 2 products"})
	}

	var productUUIDs []uuid.UUID
	for _, idStr := range req.ProductIDs {
		id, err := uuid.Parse(idStr)
		if err == nil {
			productUUIDs = append(productUUIDs, id)
		}
	}

	result, err := h.generator.CompareProducts(productUUIDs)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(result)
}

// GetDescriptionStyles returns available description styles
func (h *AIAPIHandler) GetDescriptionStyles(c *fiber.Ctx) error {
	return c.JSON(ai.DescriptionStyles)
}

// SaveGeneratedContent saves AI content to product
func (h *AIAPIHandler) SaveGeneratedContent(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	type SaveRequest struct {
		ContentType string `json:"content_type"` // description, short_description, meta_description
		Content     string `json:"content"`
	}

	var req SaveRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	var query string
	switch req.ContentType {
	case "description":
		query = `UPDATE products SET description = $1, updated_at = NOW() WHERE id = $2`
	case "short_description":
		query = `UPDATE products SET short_description = $1, updated_at = NOW() WHERE id = $2`
	case "meta_description":
		query = `UPDATE products SET meta_description = $1, updated_at = NOW() WHERE id = $2`
	default:
		return c.Status(400).JSON(fiber.Map{"error": "Invalid content type"})
	}

	_, err = h.pool.Exec(c.Context(), query, req.Content, productID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to save content"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// BulkGenerateDescriptions generates descriptions for multiple products
func (h *AIAPIHandler) BulkGenerateDescriptions(c *fiber.Ctx) error {
	type BulkRequest struct {
		ProductIDs []string `json:"product_ids"`
		Style      string   `json:"style"`
		Length     string   `json:"length"`
		AutoSave   bool     `json:"auto_save"`
	}

	var req BulkRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if len(req.ProductIDs) > 10 {
		return c.Status(400).JSON(fiber.Map{"error": "Max 10 products at once"})
	}

	type BulkResult struct {
		ProductID uuid.UUID                  `json:"product_id"`
		Success   bool                       `json:"success"`
		Result    *ai.GeneratedDescription   `json:"result,omitempty"`
		Error     string                     `json:"error,omitempty"`
	}

	var results []BulkResult

	for _, idStr := range req.ProductIDs {
		productID, err := uuid.Parse(idStr)
		if err != nil {
			results = append(results, BulkResult{
				Success: false,
				Error:   "Invalid ID",
			})
			continue
		}

		result, err := h.generator.GenerateDescription(productID, req.Style, req.Length)
		if err != nil {
			results = append(results, BulkResult{
				ProductID: productID,
				Success:   false,
				Error:     err.Error(),
			})
			continue
		}

		if req.AutoSave && result != nil {
			h.pool.Exec(c.Context(), `
				UPDATE products SET 
					description = $1, 
					short_description = $2, 
					meta_description = $3,
					updated_at = NOW()
				WHERE id = $4
			`, result.FullDescription, result.ShortDescription, result.MetaDescription, productID)
		}

		results = append(results, BulkResult{
			ProductID: productID,
			Success:   true,
			Result:    result,
		})
	}

	return c.JSON(fiber.Map{
		"results": results,
		"total":   len(results),
	})
}
