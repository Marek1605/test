package handlers

import (
	"megabuy/internal/reviews"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ReviewsAPIHandler handles reviews API
type ReviewsAPIHandler struct {
	pool   *pgxpool.Pool
	system *reviews.ReviewSystem
}

func NewReviewsAPIHandler(pool *pgxpool.Pool) *ReviewsAPIHandler {
	return &ReviewsAPIHandler{
		pool:   pool,
		system: reviews.NewReviewSystem(pool),
	}
}

// GetProductReviews returns reviews for product
func (h *ReviewsAPIHandler) GetProductReviews(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	page := c.QueryInt("page", 1)
	limit := c.QueryInt("limit", 10)
	approvedOnly := c.QueryBool("approved_only", true)

	revs, total := h.system.GetProductReviews(productID, page, limit, approvedOnly)
	stats := h.system.GetProductStats(productID)

	return c.JSON(fiber.Map{
		"reviews": revs,
		"total":   total,
		"page":    page,
		"limit":   limit,
		"stats":   stats,
	})
}

// GetVendorReviews returns reviews for vendor
func (h *ReviewsAPIHandler) GetVendorReviews(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	page := c.QueryInt("page", 1)
	limit := c.QueryInt("limit", 10)

	revs, total := h.system.GetVendorReviews(vendorID, page, limit)

	return c.JSON(fiber.Map{
		"reviews": revs,
		"total":   total,
		"page":    page,
		"limit":   limit,
	})
}

// CreateReview creates new review
func (h *ReviewsAPIHandler) CreateReview(c *fiber.Ctx) error {
	var review reviews.Review
	if err := c.BodyParser(&review); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	// Validate
	if review.Rating < 1 || review.Rating > 5 {
		return c.Status(400).JSON(fiber.Map{"error": "Rating must be 1-5"})
	}

	if review.ProductID == nil && review.VendorID == nil {
		return c.Status(400).JSON(fiber.Map{"error": "Product or vendor ID required"})
	}

	if err := h.system.CreateReview(&review); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to create review"})
	}

	return c.Status(201).JSON(fiber.Map{
		"success": true,
		"id":      review.ID,
		"message": "Review submitted for moderation",
	})
}

// ApproveReview approves review (admin)
func (h *ReviewsAPIHandler) ApproveReview(c *fiber.Ctx) error {
	reviewID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid review ID"})
	}

	if err := h.system.ApproveReview(reviewID); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to approve review"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// RejectReview rejects/deletes review (admin)
func (h *ReviewsAPIHandler) RejectReview(c *fiber.Ctx) error {
	reviewID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid review ID"})
	}

	if err := h.system.RejectReview(reviewID); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to reject review"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// AddReply adds vendor reply to review
func (h *ReviewsAPIHandler) AddReply(c *fiber.Ctx) error {
	reviewID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid review ID"})
	}

	type ReplyRequest struct {
		Reply string `json:"reply"`
	}

	var req ReplyRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	if err := h.system.AddReply(reviewID, req.Reply); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to add reply"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// MarkHelpful marks review as helpful
func (h *ReviewsAPIHandler) MarkHelpful(c *fiber.Ctx) error {
	reviewID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid review ID"})
	}

	if err := h.system.MarkHelpful(reviewID); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to mark helpful"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// GetPendingReviews returns reviews awaiting moderation (admin)
func (h *ReviewsAPIHandler) GetPendingReviews(c *fiber.Ctx) error {
	limit := c.QueryInt("limit", 20)

	revs, err := h.system.GetPendingReviews(limit)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get pending reviews"})
	}

	return c.JSON(revs)
}

// GetProductStats returns review stats for product
func (h *ReviewsAPIHandler) GetProductStats(c *fiber.Ctx) error {
	productID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid product ID"})
	}

	stats := h.system.GetProductStats(productID)
	return c.JSON(stats)
}
