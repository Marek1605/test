package handlers

import (
	"megabuy/internal/tracking"
	"megabuy/internal/vendor"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

// VendorAPIHandler handles vendor portal API
type VendorAPIHandler struct {
	pool    *pgxpool.Pool
	portal  *vendor.VendorPortal
	tracker *tracking.ClickTracker
}

func NewVendorAPIHandler(pool *pgxpool.Pool) *VendorAPIHandler {
	return &VendorAPIHandler{
		pool:    pool,
		portal:  vendor.NewVendorPortal(pool),
		tracker: tracking.NewClickTracker(pool),
	}
}

// GetDashboard returns vendor dashboard data
func (h *VendorAPIHandler) GetDashboard(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	dashboard, err := h.portal.GetDashboard(vendorID)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": "Vendor not found"})
	}

	return c.JSON(dashboard)
}

// GetVendorStats returns detailed statistics
func (h *VendorAPIHandler) GetVendorStats(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	period := c.Query("period", "30days")
	stats, err := h.tracker.GetVendorStats(vendorID, period)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get stats"})
	}

	return c.JSON(stats)
}

// GetOffers returns vendor's offers
func (h *VendorAPIHandler) GetOffers(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	page := c.QueryInt("page", 1)
	limit := c.QueryInt("limit", 20)
	search := c.Query("search", "")
	activeOnly := c.QueryBool("active_only", false)

	offers, total := h.portal.GetOffers(vendorID, page, limit, search, activeOnly)

	return c.JSON(fiber.Map{
		"offers": offers,
		"total":  total,
		"page":   page,
		"limit":  limit,
	})
}

// CreateOffer creates new offer
func (h *VendorAPIHandler) CreateOffer(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	var offer vendor.VendorOffer
	if err := c.BodyParser(&offer); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request body"})
	}

	if err := h.portal.CreateOffer(vendorID, &offer); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to create offer"})
	}

	return c.Status(201).JSON(offer)
}

// UpdateOffer updates existing offer
func (h *VendorAPIHandler) UpdateOffer(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	var offer vendor.VendorOffer
	if err := c.BodyParser(&offer); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request body"})
	}

	if err := h.portal.UpdateOffer(vendorID, &offer); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to update offer"})
	}

	return c.JSON(offer)
}

// DeleteOffer deactivates offer
func (h *VendorAPIHandler) DeleteOffer(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	offerID, err := uuid.Parse(c.Params("offerId"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid offer ID"})
	}

	if err := h.portal.DeleteOffer(vendorID, offerID); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to delete offer"})
	}

	return c.JSON(fiber.Map{"success": true})
}

// GetFeeds returns vendor's feeds
func (h *VendorAPIHandler) GetFeeds(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	feeds, err := h.portal.GetFeeds(vendorID)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get feeds"})
	}

	return c.JSON(feeds)
}

// CreateFeed creates new feed
func (h *VendorAPIHandler) CreateFeed(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	type CreateFeedRequest struct {
		Name string `json:"name"`
		URL  string `json:"url"`
		Type string `json:"type"`
	}

	var req CreateFeedRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request body"})
	}

	feed, err := h.portal.CreateFeed(vendorID, req.Name, req.URL, req.Type)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to create feed"})
	}

	return c.Status(201).JSON(feed)
}

// GetTransactions returns credit history
func (h *VendorAPIHandler) GetTransactions(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	limit := c.QueryInt("limit", 50)
	transactions, err := h.tracker.GetTransactionHistory(vendorID, limit)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to get transactions"})
	}

	return c.JSON(transactions)
}

// TopupCredit adds credit to vendor
func (h *VendorAPIHandler) TopupCredit(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	type TopupRequest struct {
		Amount        float64 `json:"amount"`
		Bonus         float64 `json:"bonus"`
		PaymentMethod string  `json:"payment_method"`
	}

	var req TopupRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request body"})
	}

	if req.Amount < 5 {
		return c.Status(400).JSON(fiber.Map{"error": "Minimum amount is 5€"})
	}

	err = h.tracker.AddCredit(vendorID, req.Amount, req.Bonus, req.PaymentMethod, "Credit topup")
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to add credit"})
	}

	// Get new balance
	var newBalance float64
	h.pool.QueryRow(c.Context(), `SELECT credit_balance FROM vendors WHERE id = $1`, vendorID).Scan(&newBalance)

	return c.JSON(fiber.Map{
		"success":     true,
		"new_balance": newBalance,
		"added":       req.Amount + req.Bonus,
	})
}

// UpdateDisplayMode changes vendor display mode
func (h *VendorAPIHandler) UpdateDisplayMode(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	type ModeRequest struct {
		Mode string `json:"mode"`
	}

	var req ModeRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request body"})
	}

	err = h.tracker.UpdateDisplayMode(vendorID, req.Mode)
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": err.Error()})
	}

	return c.JSON(fiber.Map{"success": true, "mode": req.Mode})
}

// GetCreditPackages returns available credit packages
func (h *VendorAPIHandler) GetCreditPackages(c *fiber.Ctx) error {
	packages := h.tracker.GetCreditPackages()
	return c.JSON(packages)
}

// UpdateVendor updates vendor info
func (h *VendorAPIHandler) UpdateVendor(c *fiber.Ctx) error {
	vendorID, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid vendor ID"})
	}

	var v vendor.Vendor
	if err := c.BodyParser(&v); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request body"})
	}

	v.ID = vendorID
	if err := h.portal.UpdateVendor(&v); err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Failed to update vendor"})
	}

	return c.JSON(v)
}
