package handlers

import (
	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

// RegisterAllRoutes registers all API routes
func RegisterAllRoutes(app *fiber.App, pool *pgxpool.Pool, anthropicKey string) {
	// Initialize handlers
	offersHandler := NewOffersHandler(pool)
	vendorHandler := NewVendorAPIHandler(pool)
	feedHandler := NewFeedAPIHandler(pool)
	clickHandler := NewClickAPIHandler(pool)
	reviewsHandler := NewReviewsAPIHandler(pool)
	shopHandler := NewShopAPIHandler(pool)
	analyticsHandler := NewAnalyticsAPIHandler(pool)
	
	var aiHandler *AIAPIHandler
	if anthropicKey != "" {
		aiHandler = NewAIAPIHandler(pool, anthropicKey)
	}

	// API v1
	api := app.Group("/api/v1")

	// === OFFERS ===
	offers := api.Group("/offers")
	offers.Get("/product/:id", offersHandler.GetProductOffers)
	offers.Get("/product/:id/best", offersHandler.GetBestOffer)
	offers.Post("/compare", offersHandler.CompareOffers)
	offers.Get("/click/:id", offersHandler.TrackOfferClick)

	// === VENDORS ===
	vendors := api.Group("/vendors")
	vendors.Get("/:id/dashboard", vendorHandler.GetDashboard)
	vendors.Get("/:id/stats", vendorHandler.GetVendorStats)
	vendors.Put("/:id", vendorHandler.UpdateVendor)
	
	// Vendor offers
	vendors.Get("/:id/offers", vendorHandler.GetOffers)
	vendors.Post("/:id/offers", vendorHandler.CreateOffer)
	vendors.Put("/:id/offers/:offerId", vendorHandler.UpdateOffer)
	vendors.Delete("/:id/offers/:offerId", vendorHandler.DeleteOffer)
	
	// Vendor feeds
	vendors.Get("/:id/feeds", vendorHandler.GetFeeds)
	vendors.Post("/:id/feeds", vendorHandler.CreateFeed)
	
	// Vendor billing
	vendors.Get("/:id/transactions", vendorHandler.GetTransactions)
	vendors.Post("/:id/topup", vendorHandler.TopupCredit)
	vendors.Put("/:id/display-mode", vendorHandler.UpdateDisplayMode)
	vendors.Get("/credit-packages", vendorHandler.GetCreditPackages)

	// === SHOPS (from AMARKETPLACEVENDORPORTAL) ===
	shops := api.Group("/shops")
	shops.Get("/:id", shopHandler.GetShop)
	shops.Post("/", shopHandler.CreateShop)
	shops.Put("/:id", shopHandler.UpdateShop)
	shops.Put("/:id/status", shopHandler.UpdateShopStatus)
	shops.Get("/pending", shopHandler.GetPendingShops)
	
	// Vendor-specific shop routes
	vendors.Get("/:vendorId/shop", shopHandler.GetMyShop)
	vendors.Get("/:vendorId/settings", shopHandler.GetVendorSettings)
	vendors.Put("/:vendorId/settings", shopHandler.SaveVendorSettings)
	vendors.Get("/:vendorId/display-mode", shopHandler.GetDisplayMode)
	
	// Vendor products (from APRODUKTY-VENDOR PLUGIN)
	vendors.Get("/:vendorId/products", shopHandler.GetVendorProducts)
	vendors.Get("/:vendorId/products/stats", shopHandler.GetProductStats)
	vendors.Get("/:vendorId/products/categories", shopHandler.GetCategoryStats)

	// === FEEDS ===
	feeds := api.Group("/feeds")
	feeds.Get("/", feedHandler.ListFeeds)
	feeds.Post("/preview", feedHandler.PreviewFeed)
	feeds.Get("/:id", feedHandler.GetFeed)
	feeds.Post("/", feedHandler.CreateFeed)
	feeds.Put("/:id", feedHandler.UpdateFeed)
	feeds.Delete("/:id", feedHandler.DeleteFeed)
	feeds.Post("/:id/import", feedHandler.RunImport)
	feeds.Post("/:id/import-sync", feedHandler.RunImportSync)
	feeds.Get("/:id/history", feedHandler.GetImportHistory)
	
	// Vendor feed import (from AIMPORTVENDOROVPROFIPLUGIN)
	feeds.Post("/:feedId/vendor-import", analyticsHandler.RunVendorImport)
	feeds.Post("/:feedId/vendor-import-sync", analyticsHandler.RunVendorImportSync)
	vendors.Get("/:vendorId/import-stats", analyticsHandler.GetVendorImportStats)

	// === CLICKS ===
	clicks := api.Group("/clicks")
	clicks.Post("/track/:id", clickHandler.TrackClick)
	clicks.Get("/stats", clickHandler.GetClickStats)
	clicks.Get("/recent", clickHandler.GetRecentClicks)
	clicks.Get("/top-products", clickHandler.GetTopProducts)
	clicks.Get("/top-vendors", clickHandler.GetTopVendors)

	// === REVIEWS ===
	reviews := api.Group("/reviews")
	reviews.Get("/product/:id", reviewsHandler.GetProductReviews)
	reviews.Get("/product/:id/stats", reviewsHandler.GetProductStats)
	reviews.Get("/vendor/:id", reviewsHandler.GetVendorReviews)
	reviews.Post("/", reviewsHandler.CreateReview)
	reviews.Post("/:id/approve", reviewsHandler.ApproveReview)
	reviews.Post("/:id/reject", reviewsHandler.RejectReview)
	reviews.Post("/:id/reply", reviewsHandler.AddReply)
	reviews.Post("/:id/helpful", reviewsHandler.MarkHelpful)
	reviews.Get("/pending", reviewsHandler.GetPendingReviews)

	// === ANALYTICS (from ANALITIKAPREVENDOROV) ===
	analytics := api.Group("/analytics")
	analytics.Get("/vendors/:vendorId", analyticsHandler.GetVendorAnalytics)
	analytics.Get("/vendors/:vendorId/subscription", analyticsHandler.GetSubscription)
	analytics.Post("/vendors/:vendorId/subscription", analyticsHandler.CreateSubscription)
	analytics.Delete("/subscriptions/:id", analyticsHandler.CancelSubscription)
	analytics.Get("/plans", analyticsHandler.GetSubscriptionPlans)

	// === APPROVALS (Admin) ===
	approvals := api.Group("/approvals")
	approvals.Get("/pending", shopHandler.GetPendingApprovals)
	approvals.Post("/:id/approve", shopHandler.ApproveProduct)
	approvals.Post("/:id/reject", shopHandler.RejectProduct)

	// === AI ===
	if aiHandler != nil {
		ai := api.Group("/ai")
		ai.Get("/styles", aiHandler.GetDescriptionStyles)
		ai.Post("/products/:id/description", aiHandler.GenerateDescription)
		ai.Post("/products/:id/improve", aiHandler.ImproveDescription)
		ai.Post("/products/:id/faq", aiHandler.GenerateFAQ)
		ai.Post("/products/:id/why-buy", aiHandler.GenerateWhyBuy)
		ai.Post("/products/:id/alternatives", aiHandler.FindAlternatives)
		ai.Post("/products/:id/save", aiHandler.SaveGeneratedContent)
		ai.Post("/compare", aiHandler.CompareProducts)
		ai.Post("/bulk-descriptions", aiHandler.BulkGenerateDescriptions)
	}

	// === PUBLIC ENDPOINTS ===
	// Click redirect (short URL)
	app.Get("/go/:id", func(c *fiber.Ctx) error {
		return clickHandler.TrackClick(c)
	})
}

// RegisterPublicRoutes registers only public routes (no auth needed)
func RegisterPublicRoutes(app *fiber.App, pool *pgxpool.Pool) {
	offersHandler := NewOffersHandler(pool)
	clickHandler := NewClickAPIHandler(pool)
	reviewsHandler := NewReviewsAPIHandler(pool)

	// Public API
	pub := app.Group("/api/public")

	// Product offers (for frontend)
	pub.Get("/products/:id/offers", offersHandler.GetProductOffers)
	pub.Get("/products/:id/best-offer", offersHandler.GetBestOffer)
	
	// Reviews (read only)
	pub.Get("/products/:id/reviews", reviewsHandler.GetProductReviews)
	pub.Get("/products/:id/rating", reviewsHandler.GetProductStats)
	
	// Click redirect
	pub.Get("/click/:id", func(c *fiber.Ctx) error {
		c.Request().URI().SetQueryString("redirect=1")
		return clickHandler.TrackClick(c)
	})
}
