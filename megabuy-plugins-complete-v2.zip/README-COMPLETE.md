# MegaBuy Go - KOMPLETNÁ IMPLEMENTÁCIA VŠETKÝCH WORDPRESS PLUGINOV

Všetky WordPress pluginy z tvojho screenshotu sú teraz implementované v Go.

## 📦 Plugin → Go Module Mapping

### Hlavné pluginy (zvýraznené)

| WordPress Plugin | Go Modul | Funkcionalita |
|-----------------|----------|---------------|
| **AMARKETPLACEVENDORPORTAL** | `internal/vendor/shop.go` | Shop management, vendor settings, registrácia |
| **ANALITIKAPREVENDOROV** | `internal/analytics/` | Smart analytics, subscription plány |
| **ANASTAVENIEVENDORA** | `internal/vendor/shop.go` | Vendor settings (return policy, shipping, XML, API) |
| **APRODUKTY-VENDOR PLUGIN** | `internal/vendor/products.go` | Product management, approval workflow, FREE/PAID mode |
| **AIMPORTVENDOROVPROFIPLUGIN** | `internal/importer/vendor_importer.go` | Master/Affiliate product creation, EAN matching |

### Ostatné pluginy

| WordPress Plugin | Go Modul |
|-----------------|----------|
| mk-click-tracking | `internal/tracking/click_tracker.go` |
| mk-cpc-system | `internal/tracking/click_tracker.go` |
| mk-vendor-statistics | `internal/vendor/portal.go` + `internal/analytics/` |
| mk-vendor-reports | `internal/analytics/analytics.go` |
| AZOBRAZENIEPONUKPREDAJCOV | `internal/handlers/offers.go` |
| mk-smart-buy-button-FINAL | `internal/handlers/offers.go` |
| ARECENZIE | `internal/reviews/reviews.go` |
| megaprice-ai | `internal/ai/generator.go` |
| APODKATEGORIE | Frontend component (React) |

## 🔗 Architektúra prepojení

```
AMARKETPLACEVENDORPORTAL (hlavný plugin)
├── mk-vendor-statistics ──────→ analytics/analytics.go
├── mk-click-tracking ─────────→ tracking/click_tracker.go
├── mk-cpc-system ─────────────→ tracking/click_tracker.go
├── ANALITIKAPREVENDOROV ──────→ analytics/analytics.go
├── ANASTAVENIEVENDORA ────────→ vendor/shop.go (settings)
└── APRODUKTY-VENDOR PLUGIN ───→ vendor/products.go

AIMPORTVENDOROVPROFIPLUGIN (samostatný)
├── Feed processor ────────────→ importer/vendor_importer.go
├── EAN manager ───────────────→ importer/vendor_importer.go
├── Master product creation ───→ importer/vendor_importer.go
└── Affiliate offer creation ──→ importer/vendor_importer.go
```

## 🚀 API Endpoints

### Shop Management (AMARKETPLACEVENDORPORTAL)
```
GET  /api/v1/shops/:id              - Detail shopu
POST /api/v1/shops                  - Registrácia shopu
PUT  /api/v1/shops/:id              - Update shopu
PUT  /api/v1/shops/:id/status       - Admin: zmena statusu
GET  /api/v1/shops/pending          - Admin: pending shopy
```

### Vendor Settings (ANASTAVENIEVENDORA)
```
GET  /api/v1/vendors/:id/shop       - Môj shop
GET  /api/v1/vendors/:id/settings   - Nastavenia vendora
PUT  /api/v1/vendors/:id/settings   - Uložiť nastavenia
GET  /api/v1/vendors/:id/display-mode - Display mode info
```

### Vendor Products (APRODUKTY-VENDOR PLUGIN)
```
GET  /api/v1/vendors/:id/products           - Produkty vendora
GET  /api/v1/vendors/:id/products/stats     - Štatistiky produktov
GET  /api/v1/vendors/:id/products/categories - Rozdelenie podľa kategórií
```

### Analytics (ANALITIKAPREVENDOROV)
```
GET  /api/v1/analytics/vendors/:id           - Kompletná analytika
GET  /api/v1/analytics/vendors/:id/subscription - Subscription info
POST /api/v1/analytics/vendors/:id/subscription - Vytvoriť subscription
GET  /api/v1/analytics/plans                 - Dostupné plány
```

### Vendor Feed Import (AIMPORTVENDOROVPROFIPLUGIN)
```
POST /api/v1/feeds/:id/vendor-import      - Spustiť vendor import
POST /api/v1/feeds/:id/vendor-import-sync - Sync vendor import
GET  /api/v1/vendors/:id/import-stats     - Import štatistiky
```

### Approvals (Admin)
```
GET  /api/v1/approvals/pending     - Pending approvals
POST /api/v1/approvals/:id/approve - Schváliť
POST /api/v1/approvals/:id/reject  - Zamietnuť
```

## 📊 Database Schema

### Nové tabuľky
- `vendor_shops` - Shop management (status, optimization score, credits)
- `vendor_settings` - Key-value settings pre vendorov
- `product_approvals` - Workflow pre schvaľovanie zmien
- `analytics_subscriptions` - Subscription plány pre analytiku
- `reviews` - Recenzie produktov a vendorov
- `transactions` - CPC transakcie
- `brands` - Značky produktov
- `attributes` + `product_attribute_values` - Atribúty

### Views
- `vendor_stats_daily` - Denné štatistiky vendorov
- `product_stats` - Štatistiky produktov
- `vendor_overview` - Prehľad vendorov

## 🎯 FREE vs PAID Mode Logic

Z APRODUKTY-VENDOR PLUGIN:

```go
// FREE mode restrictions
if isFree {
    p.Position = 0         // Buy Box always "Nie"
    p.VendorCount = 1      // Always show 1 vendor
    p.ClickCount = 0       // Hide real stats
    p.ConversionRate = 0
    // Category changes require approval
}

// PAID mode
// - Full statistics
// - Direct category changes
// - Buy Box position visible
// - Real competitor count
```

## 🔄 Vendor Import Flow (AIMPORTVENDOROVPROFIPLUGIN)

```
1. Download feed (XML/CSV/JSON)
2. Parse items
3. For each item:
   a. Try match by EAN → existing master
   b. Try match by SKU → existing master
   c. Try match by title → existing master
   d. No match → create new master product
4. Create/update affiliate offer for vendor
5. Link offer to master product
6. Update master product prices (min/max)
7. Deactivate missing offers (optional)
```

## 🏗️ Deployment

```bash
# 1. Rozbaľ na serveri
cd /root/megabuy-go
unzip -o megabuy-plugins-complete-v2.zip

# 2. Spusti migráciu
psql -U postgres -d megabuy < migrations/003_all_plugins.sql

# 3. Rebuild
go build -o megabuy ./cmd/server

# 4. Redeploy v Coolify
```

## 📁 Štruktúra súborov

```
internal/
├── analytics/
│   └── analytics.go          (ANALITIKAPREVENDOROV)
├── ai/
│   └── generator.go          (megaprice-ai)
├── importer/
│   ├── feed_importer.go      (mk-feed-importer)
│   └── vendor_importer.go    (AIMPORTVENDOROVPROFIPLUGIN)
├── reviews/
│   └── reviews.go            (ARECENZIE)
├── tracking/
│   └── click_tracker.go      (mk-click-tracking, mk-cpc-system)
├── vendor/
│   ├── portal.go             (mk-vendor-statistics)
│   ├── products.go           (APRODUKTY-VENDOR PLUGIN)
│   └── shop.go               (AMARKETPLACEVENDORPORTAL, ANASTAVENIEVENDORA)
└── handlers/
    ├── offers.go             (AZOBRAZENIEPONUKPREDAJCOV)
    ├── vendor_api.go
    ├── feed_api.go
    ├── ai_api.go
    ├── click_api.go
    ├── reviews_api.go
    ├── shop_api.go           (NEW)
    ├── analytics_api.go      (NEW)
    └── routes.go
```

## ✅ Kompletný zoznam implementovaných funkcií

### AMARKETPLACEVENDORPORTAL
- ✅ Shop registration
- ✅ Shop status management (pending, active, suspended, rejected)
- ✅ Optimization score calculation
- ✅ Credit balance tracking
- ✅ Display mode (free, paid, premium)
- ✅ Frontend dashboard data

### ANASTAVENIEVENDORA
- ✅ Contact settings
- ✅ Business info (IČO, DIČ, IČ DPH)
- ✅ Address
- ✅ Return/Complaint/Warranty policy
- ✅ Shipping methods
- ✅ Logo/Banners
- ✅ XML Feed URL
- ✅ API key management

### APRODUKTY-VENDOR PLUGIN
- ✅ Product listing with stats
- ✅ FREE mode restrictions
- ✅ PAID mode full features
- ✅ Category stats
- ✅ Approval workflow
- ✅ Buy Box position tracking

### AIMPORTVENDOROVPROFIPLUGIN
- ✅ Multi-format feed parsing (XML, CSV, JSON)
- ✅ EAN-based master product matching
- ✅ SKU-based matching
- ✅ Title-based fuzzy matching
- ✅ Master product creation
- ✅ Affiliate offer creation
- ✅ Checksum-based change detection
- ✅ Deactivate missing offers

### ANALITIKAPREVENDOROV
- ✅ Comprehensive analytics
- ✅ Daily breakdown
- ✅ Top products
- ✅ Top categories
- ✅ Competitor analysis
- ✅ Trend calculation
- ✅ Subscription plans (basic, pro, enterprise)
